# Wellmeadows Hospital (G07) — MySQL / phpMyAdmin → Microsoft SQL Server

**Project:** Wellmeadows Hospital Administrator System (G07)
**Source:** MySQL via phpMyAdmin (Laragon/XAMPP), `pdo_mysql`
**Target:** SQL Server 2016+ (Express 2022/2025 recommended), `pdo_sqlsrv`
**Based on:** a colleague's migration report for a different Wellmeadows build, adapted to this codebase (`api/*.php`, `sql/*.sql`, 13 tables).

---

## 1. Summary

The project zip (`WellmeadowsHosp_sqlserver_wip`) was already half-converted to T-SQL. It looked finished, but an audit against the lessons in the colleague's report found **3 blockers** (the app could not have started), **6 silent defects** (the app would have run but shown wrong data or broken buttons with no error), and **8 robustness gaps**. All of them are fixed in this version.

| | Before (WIP) | After |
|---|---|---|
| `DatabaseG07.sql` runs in SSMS | ❌ fails on `file` (reserved word) | ✅ parses, re-runnable, self-checks row counts |
| PHP connects to Express | ❌ certificate error + `sa` disabled | ✅ `TrustServerCertificate`, Windows auth |
| JSON shape matches MySQL | ❌ ids as `"5"`, `".15"`, `"09:30:00.0000000"` | ✅ identical to MySQL |
| Thai text | ❌ saved as `?????` (VARCHAR) | ✅ NVARCHAR |
| Existing MySQL data | ❌ no way to move it | ✅ `tools/migrate_mysql_to_mssql.php` |
| Proof it worked | ❌ none | ✅ `tools/verify_migration.php` (5 checks) |
| Setup diagnosis | ❌ trial and error | ✅ `tools/check_env.php` (stops at first failure, says what to do) |

Nothing in `assets/js/` needed a logic change. The browser cannot tell which database it is talking to.

---

## 2. What was wrong in the WIP version

### 2.1 Blockers — the app could not start

| # | Problem | Where | Fix |
|---|---|---|---|
| B1 | `file VARCHAR(MAX)` in 7 `CREATE TABLE`s. **FILE is a reserved word in T-SQL**, so the script stops at the `staff` table. | `sql/DatabaseG07.sql` | Quoted as `[file]` everywhere (the PHP already bracket-quoted it). |
| B2 | ODBC Driver 18 encrypts by default; a local Express install has only a self-signed certificate → *"certificate chain was issued by an authority that is not trusted"*. | `api/db.php` | `TrustServerCertificate=1` (switchable in `api/config.php`). |
| B3 | Default login was `sa` / empty password. A Basic Express install is **Windows Authentication only** and `sa` is disabled. The code had no way to use Windows auth. | `api/db.php` | `DB_AUTH = 'windows'` passes `NULL` user/password (the documented way). `'sql'` mode still available. |

### 2.2 Silent defects — no error, wrong behaviour

These are the important ones. Every row count would have matched.

| # | Problem | Visible effect in THIS app | Fix |
|---|---|---|---|
| S1 | `pdo_sqlsrv` returns INT as string (`"5"`); `pdo_mysql` on PHP 8.1+ returns `5`. | `admin-users.js` line 71: `usersCache.find(u => u.id === id)` — **User Management "Edit" button does nothing**; "(you)" label never shows. | `PDO::SQLSRV_ATTR_FETCHES_NUMERIC_TYPE => true` |
| S2 | DECIMAL `0.15` returned as `".15"`. | Supplies page shows cost `.15`, `.80`, `.05`, `.10` for all four seed items. | `PDO::SQLSRV_ATTR_FORMAT_DECIMALS => true` |
| S3 | `TIME` / `DATETIME2` default to 7-digit precision → `"09:30:00.0000000"`. | Outpatient/appointment times display with `.0000000`; `new Date(last_login)` can be Invalid Date in some browsers. | `TIME(0)`, `DATETIME2(0)` → `"09:30:00"`, `"2026-09-16 09:35:00"` (same as MySQL). |
| S4 | All text columns were `VARCHAR` (code-page, not Unicode). | Any Thai name/address saved as `?????`. | Text → `NVARCHAR`; base64 files stay `VARCHAR(MAX)` (ASCII, half the size). |
| S5 | The browser sends `uploadedAt` / `approvedAt` as `toISOString()` (`2026-09-16T02:35:00.123Z`, UTC). Storing that relies on SQL Server's string parsing and would store UTC. | Wrong timestamps (7 h off in Thailand) or conversion errors on save/approve. | `normalize_value()` parses it in PHP and stores local time (`APP_TIMEZONE`). |
| S6 | Fresh install ≠ README: `DatabaseG07.sql` lacked `staff01` / `nurse01` / `director01`, and seeded admin as `Administrator` while `add_role_accounts.sql` expects `Admin`. | The logins listed in the docs don't exist on a fresh database. | All 5 accounts in the main script, admin role `Admin`. All 5 bcrypt hashes verified with `password_verify()`. |

### 2.3 Robustness gaps

| # | Problem | Fix |
|---|---|---|
| R1 | Any SQL error became a PHP HTML error page → front end showed only "Failed to save". | Global JSON exception handler; SQL Server error numbers mapped to plain messages (duplicate, too long, wrong type, missing table, login refused…). `APP_DEBUG` adds the raw message. |
| R2 | `lastInsertId()` with `pdo_sqlsrv` runs a separate identity query after the insert (session-wide; can return the wrong id if a trigger is ever added). | `INSERT … OUTPUT INSERTED.id` — id comes back from the same statement. |
| R3 | `staffNo … UNIQUE`: MySQL allows many NULLs, SQL Server only one. | Filtered unique index `WHERE staffNo IS NOT NULL`. |
| R4 | Script not re-runnable (second run fails on `CREATE TABLE`). | `DROP TABLE IF EXISTS …` + explicit warning in the header. |
| R5 | Search: `%`, `_`, `[` in the search box acted as wildcards; INT/DATE columns relied on implicit conversion. | `CAST(col AS NVARCHAR(MAX)) LIKE ? ESCAPE '\'` + `like_escape()`. |
| R6 | Every `GET ward` ran 10 separate INSERT checks. | One set-based `INSERT … SELECT FROM (VALUES …) WHERE NOT EXISTS`. |
| R7 | `sql/DatabaseG07.sql` only holds seed data — **records entered while on MySQL would be lost**. | `tools/migrate_mysql_to_mssql.php` copies live data, keeping original ids. |
| R8 | `crud.js` fills a blank first field with e.g. `WAR1234` / `PHA1234`, but `ward.number` and `pharma.drugNo` are INT → cryptic conversion error. | API now rejects it with *"number" must be a whole number (got "WAR1234")*. The front-end generator itself is left as-is (see §8). |

Also: bad dates/times now get a clear 400 naming the field; accepted input formats are `YYYY-MM-DD`, `DD/MM/YYYY`, `HH:MM`, `HH:MM:SS`, `2:15 pm`, and browser ISO timestamps.

---

## 3. Lessons from the colleague's report — what was reused

| Lesson in their report | Applies here? | What was done |
|---|---|---|
| Integers arrive as text (their Defect 1) | Yes — breaks User Management | Same attribute (S1) |
| Decimals lose leading zero (their Defect 2) | Yes — Supplies page | Same attribute (S2) |
| `TrustServerCertificate=1` for Express | Yes | B2 |
| Don't trust the checked-in schema; read the live DB | Yes | Migration tool reads MySQL `information_schema` and **lists columns that exist only in MySQL** before copying |
| Write SQL files as UTF-8 **with BOM** | Yes | `DatabaseG07.sql` saved as UTF-8 BOM |
| Verify with COUNT + CONTENT + WRITE + PARITY | Yes | `verify_migration.php` (COUNT, CONTENT, UNICODE, SHAPE, WRITE) |
| Match PHP driver to PHP version / TS / x64 | Yes | `check_env.php` prints the exact DLL names. Update: driver **5.13** (Feb 2026) supports PHP 8.3–8.5 and dropped 8.1/8.2; use **5.12** for PHP 8.1/8.2. |
| winget SQL Server 2022 package retired → use 2025 | Probably (their finding) | Recommended 2025 Express; 2022 via the Microsoft download page also works |
| Never `--silent` the SQL Server bootstrapper | Yes | Noted in §4 |
| Two different `sqlcmd` tools (`-f 65001`) | Yes | Noted in §4 |
| Laragon config paths stale after moving the folder | Maybe | Noted in troubleshooting |
| Dual-driver switch (`DB_DRIVER`) | **Not adopted** | This codebase is already SQL-Server-only. Rollback = keep MySQL untouched + your previous zip (§7). Maintaining two schemas doubles the work for a class project. |
| No IDENTITY columns | **Different here** | This project uses `IDENTITY`; the migration uses `SET IDENTITY_INSERT` to keep original ids, then reseeds. |
| No foreign keys | Same | Kept — no FKs, so tables can be loaded in any order. |

---

## 4. Procedure (do it in this order)

### Step 1 — Install SQL Server (Administrator)
```powershell
winget install --id Microsoft.SQLServer.2025.Express --accept-package-agreements --accept-source-agreements
winget install --id Microsoft.msodbcsql.18 --accept-package-agreements --accept-source-agreements
```
Choose **Basic**. Do **not** add `--silent` (the bootstrapper is a GUI and hangs). Also install **SSMS**.

### Step 2 — PHP driver (no Administrator)
```powershell
php tools/check_env.php
```
Step [1] prints the two DLL names for *your* PHP (e.g. `php_pdo_sqlsrv_83_ts_x64.dll`). Download that release from `github.com/microsoft/msphpsql/releases`, copy both DLLs into PHP's `ext` folder, add to `php.ini`:
```ini
extension=php_sqlsrv_83_ts_x64.dll
extension=php_pdo_sqlsrv_83_ts_x64.dll
```
Restart Apache. **Run `check_env.php` with the same `php.exe` Apache uses** — Laragon/XAMPP often have several.

### Step 3 — Create the database
SSMS → open `sql/DatabaseG07.sql` → F5. The last result grid must show `OK` on all 13 rows.
Or: `sqlcmd -S "localhost\SQLEXPRESS" -E -C -i sql\DatabaseG07.sql`
(Classic ODBC `sqlcmd` needs `-f 65001`; the newer go-sqlcmd rejects it.)

### Step 4 — Configure
Edit **only** `api/config.php` if your server name/auth differ. Re-run `php tools/check_env.php` until the end says *All checks passed*.

### Step 5 — Copy existing MySQL data (skip if you only need seed data)
Start MySQL in Laragon, then:
```powershell
php tools/migrate_mysql_to_mssql.php          # dry run — read the plan
php tools/migrate_mysql_to_mssql.php --run    # copy
```
If the dry run shows `!! MySQL-only columns`, add those columns to `sql/DatabaseG07.sql` first — otherwise that data is dropped (or use `--force` knowingly). PHP needs both `pdo_mysql` and `pdo_sqlsrv` loaded for this step.

### Step 6 — Prove it
```powershell
php tools/verify_migration.php --write-test
```
Must end with `RESULT: all checks passed.`

### Step 7 — Test in the browser
Settings → System Status (shows SQL Server edition/version + row counts). Then click through: log in as each role, add/edit/delete a record, approve a requisition, open **User Management → Edit** (this is the button S1 would have broken), check a supply cost shows `0.15`.

---

## 5. Verification

| Check | Method | Catches |
|---|---|---|
| COUNT | Row count per table, MySQL vs SQL Server | Missing rows |
| CONTENT | Every column of every row, matched by id, type-aware compare | Truncation, wrong conversion, lost values |
| UNICODE | Rows containing non-ASCII text, before vs after | `?????` corruption |
| SHAPE | PHP types/format of what SQL Server returns | S1, S2, S3 — the defects row counts cannot see |
| WRITE | Re-save every row through the API's own `normalize_value()`, re-read, compare, **ROLLBACK** | Save path breaking data |

**What was tested in preparing this version** (no SQL Server was available in the build environment, so the live checks above must be run on your machine):
- All PHP files: `php -l` clean (PHP 8.3).
- `DatabaseG07.sql`: every batch parsed as T-SQL; every INSERT's value count matches its column list; expected row counts: users 5, ward 12, staff 6, patient 6, outpatient 0, appointment 2, medication 3, supply 4, pharma 13, requisition 1, supplier 2, bedQueue 1, leave_request 2 (**57 rows**).
- `normalize_value()` unit-tested: ISO-Z timestamp → local time, `DD/MM/YYYY`, `2:15 pm`, `09:30:00.0000000`, rejects `WAR1234` for INT, `31/02/2004`, `25:00`.
- All 5 seeded bcrypt hashes verified against their documented passwords.
- API without the driver returns a JSON error with a hint (no HTML page).

---

## 6. Type conversion reference

| MySQL | SQL Server | Why |
|---|---|---|
| `VARCHAR(n)` text | `NVARCHAR(n)` | Unicode (Thai) |
| `TEXT` / `LONGTEXT` text | `NVARCHAR(MAX)` | Unicode |
| base64 files/avatars/photos | `VARCHAR(MAX)` | ASCII only; half the storage |
| bcrypt `pass` | `VARCHAR(255)` | ASCII |
| `INT AUTO_INCREMENT` | `INT IDENTITY(1,1)` | |
| `DECIMAL(p,s)` | `DECIMAL(p,s)` | + `FORMAT_DECIMALS` |
| `DATE` | `DATE` | |
| `TIME` | `TIME(0)` | Same string as MySQL |
| `DATETIME` / `TIMESTAMP` | `DATETIME2(0)` | Same string as MySQL |
| `NOW()` / `CURRENT_TIMESTAMP` | `SYSDATETIME()` | |
| `` `name` `` | `[name]` | Required for `user`, `file`, `desc`, `date`, `time`, `start` |
| `UNIQUE` (nullable) | filtered unique index | MySQL allows many NULLs |
| `INSERT IGNORE` | `IF NOT EXISTS` / `WHERE NOT EXISTS` | |
| `ADD COLUMN IF NOT EXISTS` | check `sys.columns` first | |
| `GREATEST()` | `IIF()` (pre-2022) | |
| `LIMIT n` | `TOP n` / `OFFSET…FETCH` | (not used in this app) |
| `SHOW COLUMNS` | `INFORMATION_SCHEMA.COLUMNS` | |
| `DATABASE()` | `DB_NAME()` | |
| collation `utf8mb4_0900_ai_ci` | `Latin1_General_100_CI_AI_SC` | Case- and accent-insensitive like MySQL (logins stay case-insensitive) |

---

## 7. Files changed

| File | Change |
|---|---|
| `api/config.php` | **New.** The only file with connection settings (default `localhost\MSSQLSERVER01`) |
| `api/sqlsrv_helpers.php` | **New.** Connection, error translation, `normalize_value()`, `like_escape()` — shared by API and tools |
| `api/db.php` | Uses the two above; JSON exception handler; driver-missing message |
| `api/table.php` | Type normalisation, `OUTPUT INSERTED.id`, safe search, set-based ward seed, id validation, 404 on missing row |
| `api/status.php` | Reports SQL Server edition/version, server, collation |
| `api/auth.php`, `api/users.php` | Unchanged (already correct T-SQL) |
| `sql/DatabaseG07.sql` | B1, S3, S4, S6, R3, R4 + row-count self-check |
| `sql/add_*.sql` | Unchanged (still valid upgrade scripts) |
| `tools/check_env.php` | **New.** Environment diagnosis |
| `tools/migrate_mysql_to_mssql.php` | **New.** MySQL → SQL Server data copy |
| `tools/verify_migration.php` | **New.** 5-check verification |
| `assets/js/settings.js` | Shows server version; points to `api/config.php` |
| `assets/js/data.js`, `index.php` | Stale "MySQL/localStorage" comments corrected |
| `README.md` | Replaces `Readme_G07.txt`: full setup, configuration, API, tools, troubleshooting |

The three `tools/` scripts refuse to run from a browser.

**Rollback:** MySQL is only ever *read* by the tools, so your phpMyAdmin database stays intact. To go back, run your previous (MySQL) version of the project against it.

---

## 8. Known issues NOT fixed (outside migration scope — recommended next)

A migration should prove *nothing changed*; these change behaviour, so they are listed, not silently altered.

1. **Privilege escalation (fix before any demo):** `auth.php?action=register` accepts `role` from the client — anyone can register as `Admin`. Force self-registered accounts to a non-admin role server-side.
2. **Deleted wards come back:** `GET table.php?table=ward` re-inserts wards 1–10 whenever they're missing, so deleting one of them never sticks. Move the seeding into the SQL script only.
3. **Blank → NULL on save:** editing a record turns `''` into `NULL` (existing behaviour, reported by `--write-test`). Harmless if the UI treats both as empty.
4. **Reads need no login:** patient data is readable via `GET` without a session.
5. **Default passwords:** `admin/admin123` — `check_env.php` warns while it's unchanged.
6. **Front-end id generator:** `crud.js` generates text ids (`WAR1234`) for INT fields; now rejected with a clear message, but the generator should produce numbers for `ward.number` and `pharma.drugNo`.

---

## 9. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `pdo_sqlsrv extension is not loaded` | DLL missing or wrong build | `check_env.php` step 2; TS vs NTS and PHP version must match exactly — wrong builds fail silently |
| `This extension requires the Microsoft ODBC Driver` | ODBC driver missing | Install ODBC Driver 18 x64 |
| `certificate chain … not trusted` | ODBC 18 encryption | `DB_TRUST_SERVER_CERT = true` |
| `Login failed for user 'NT AUTHORITY\SYSTEM'` | Apache runs as a service | Use `DB_AUTH = 'sql'`, or add that login in SSMS |
| `Login failed for user 'sa'` | Mixed mode off / sa disabled | SSMS → Server Properties → Security → mixed mode; enable `sa`; restart service |
| `Cannot reach SQL Server` | Service stopped / wrong name | `services.msc` → SQL Server (SQLEXPRESS); Express = `localhost\SQLEXPRESS` |
| `Database "wellmeadows" not found` | Script not run | Step 3 |
| `Incorrect syntax near 'file'` | Old WIP schema | Use the new `DatabaseG07.sql` |
| Times show `.0000000` | DB created from old WIP schema | Re-create with new script (then re-run the migration tool) |
| Thai shows `?????` | Old VARCHAR schema | Same |
| phpMyAdmin suddenly empty | Laragon folder moved; `my.ini` points to a dead `datadir` and MySQL created an empty one | Fix `datadir` in `my.ini`; data is still in the old folder |
| Migration: `IDENTITY_INSERT is already ON for table …` | Previous run interrupted | Reconnect (it's per-session) and re-run |

---

## 10. Command reference

```powershell
# diagnose
php tools/check_env.php
php -r "print_r(PDO::getAvailableDrivers());"

# create database
sqlcmd -S "localhost\SQLEXPRESS" -E -C -i sql\DatabaseG07.sql

# move data + prove it
php tools/migrate_mysql_to_mssql.php
php tools/migrate_mysql_to_mssql.php --run
php tools/verify_migration.php --write-test

# quick look
sqlcmd -S "localhost\SQLEXPRESS" -E -C -d wellmeadows -Q "SELECT name FROM sys.tables"

# from the app
http://localhost/WellmeadowsHosp/api/status.php
```
