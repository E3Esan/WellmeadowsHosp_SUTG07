-- ============================================================
-- Adds the three new role accounts (Staff, Charge Nurse, Medical
-- Director) plus normalizes the seeded admin's role string, without
-- touching any other data. Safe to run on a database that already has
-- sql/schema.sql imported — uses INSERT IGNORE so it won't error or
-- duplicate rows if it's ever run twice.
--
-- Import: phpMyAdmin > select the `wellmeadows` database > Import tab
-- > choose this file > Go.
--
-- If you're setting up fresh instead, just import sql/schema.sql —
-- it already includes these accounts, you don't need this file too.
-- ============================================================

USE wellmeadows;

-- 'Administrator' -> 'Admin' so it matches the role strings the new
-- permission system checks (assets/js/permissions.js). Harmless if your
-- admin row is already 'Admin' or something else you've since changed.
UPDATE users SET role = 'Admin' WHERE user = 'admin' AND role = 'Administrator';

INSERT IGNORE INTO users (user, pass, role, fullName, email, phone, position) VALUES
('staff01', '$2b$10$szQuJYuGjUlpPO/Td6PDB.6MNQWbV.77bf8P6b8J90S3/sBa24jxK', 'Staff', 'Alex Carter', 'staff01@wellmeadows.example', '01506-100001', 'Ward Assistant'),
('nurse01', '$2b$10$ONEZAxMWfloP8ulcaO0dR.wlaJq5NweIzFuysRDczfPXH.Lm7HKYi', 'Charge Nurse', 'Priya Shah', 'nurse01@wellmeadows.example', '01506-100002', 'Charge Nurse'),
('director01', '$2b$10$A3p9/Aeu.l7o.DccsO/CYOVTDuAHYJpzaHD2bdHvZfO48dyTI98ue', 'Medical Director', 'Dr. James Whitfield', 'director01@wellmeadows.example', '01506-100003', 'Medical Director');

-- Login credentials (plain text here only so you have them — the `pass`
-- column above stores bcrypt hashes, never the real password):
--   staff01    / Staff@2026     (role: Staff)
--   nurse01    / Nurse@2026     (role: Charge Nurse)
--   director01 / Director@2026  (role: Medical Director)
--   admin      / admin123       (role: Admin — already existed)
