<?php
// ============================================================
// Read-only system status for the Settings page: proves the DB connection
// is live and shows how many rows are in each table right now.
//   GET status.php -> { connected, dbName, serverTime, tables: {ward: 2, ...} }
// ============================================================

require __DIR__ . '/db.php';

$tables = ['ward','staff','patient','outpatient','appointment','medication','supply','pharma','requisition','supplier','bedQueue','leave_request','users'];
$counts = [];
foreach ($tables as $t) {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) AS c FROM `$t`");
        $counts[$t] = (int) $stmt->fetch()['c'];
    } catch (PDOException $e) {
        $counts[$t] = null; // table missing — schema.sql probably not (re)imported yet
    }
}

$dbNameRow = $pdo->query('SELECT DATABASE() AS db')->fetch();
$timeRow = $pdo->query('SELECT NOW() AS now')->fetch();

send([
    'connected'  => true,
    'dbName'     => $dbNameRow['db'] ?? null,
    'serverTime' => $timeRow['now'] ?? null,
    'phpVersion' => PHP_VERSION,
    'tables'     => $counts,
]);
