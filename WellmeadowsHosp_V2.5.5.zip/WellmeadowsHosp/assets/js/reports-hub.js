// ===== Report hub and rendering helpers =====
function renderReportsHub(query = '') {
  const reportHub = document.getElementById('reportHub');
  if (!reportHub) return;

  const reportKeys = [
    ['ward', 'Wards'],
    ['staff', 'Staff'],
    ['patient', 'Patients'],
    ['outpatient', 'Outpatients'],
    ['appointment', 'Appointments'],
    ['medication', 'Medication'],
    ['supply', 'Supplies'],
    ['pharma', 'Pharmaceuticals'],
    ['requisition', 'Requisitions'],
    ['supplier', 'Suppliers'],
    ['leave', 'Leave Requests']
  ];

  const search = String(query || '').trim().toLowerCase();
  const filtered = reportKeys.filter(([key, label]) => !search || key.toLowerCase().includes(search) || label.toLowerCase().includes(search));

  reportHub.innerHTML = filtered.map(([key, label]) => {
    const rows = DB[key] || [];
    const itemCount = rows.length;
    return `
      <div class="bubble" style="border:1px solid var(--bd); border-radius:12px; padding:14px; background:#fff; margin-bottom:12px; display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:12px;">
        <div>
          <strong>${label}</strong>
          <div style="font-size:12px; color:#667; margin-top:4px;">${itemCount} record${itemCount === 1 ? '' : 's'}</div>
        </div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <button class="act" onclick="printReportByKey('${key}')">Print ${label}</button>
        </div>
      </div>
    `;
  }).join('') + (filtered.length ? `<div style="margin-top:12px;"><button class="act" onclick="printAllReports()">Print All Reports</button></div>` : '<div style="color:#667; margin-top:12px;">No matching report groups found.</div>');
}

function buildReportTable(key) {
  const schema = SCHEMA[key];
  const rows = DB[key] || [];
  if (!schema || !rows.length) {
    return '<p>No data available for this report.</p>';
  }

  const headers = schema.labels.slice(0, Math.min(schema.labels.length, 8));
  const body = rows.map(row => {
    const cells = schema.fields.slice(0, Math.min(schema.fields.length, 8)).map(field => {
      const value = row[field];
      return `<td>${value === undefined || value === null || value === '' ? '-' : value}</td>`;
    }).join('');
    return `<tr>${cells}</tr>`;
  }).join('');

  return `
    <table border="1" cellpadding="6" cellspacing="0" style="width:100%; border-collapse:collapse; margin-bottom:18px;">
      <thead>
        <tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr>
      </thead>
      <tbody>${body}</tbody>
    </table>
  `;
}

function printReportByKey(key) {
  const label = (SCHEMA[key] && SCHEMA[key].labels) ? key.charAt(0).toUpperCase() + key.slice(1) : 'Report';
  const rows = DB[key] || [];
  if (!rows.length) {
    alert('There is no data available for this report.');
    return;
  }
  const win = window.open('', '_blank', 'width=980,height=700');
  win.document.write(`<!DOCTYPE html><html><head><title>${label} Report</title><style>body{font-family:Arial,sans-serif;margin:24px;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #ccc;padding:8px;text-align:left;vertical-align:top;} h2{margin-bottom:12px;}</style></head><body><h2>${label} Report</h2>${buildReportTable(key)}</body></html>`);
  win.document.close();
  win.focus();
  win.print();
}

function printAllReports() {
  const keys = Object.keys(SCHEMA).filter(key => Array.isArray(DB[key]));
  const body = keys.map(key => `<h2>${key.charAt(0).toUpperCase() + key.slice(1)} Report</h2>${buildReportTable(key)}`).join('');
  const win = window.open('', '_blank', 'width=1200,height=800');
  win.document.write(`<!DOCTYPE html><html><head><title>All Hospital Reports</title><style>body{font-family:Arial,sans-serif;margin:24px;} table{border-collapse:collapse;width:100%;margin-bottom:24px;} th,td{border:1px solid #ccc;padding:8px;text-align:left;vertical-align:top;} h2{margin:0 0 12px;} </style></head><body><h1>Wellmeadows Hospital Report Hub</h1>${body}</body></html>`);
  win.document.close();
  win.focus();
  win.print();
}

