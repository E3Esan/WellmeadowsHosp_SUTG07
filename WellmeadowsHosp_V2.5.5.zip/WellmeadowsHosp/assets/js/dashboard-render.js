// ===== Dashboard rendering =====
function renderDash() {
  // render compact staff-on-duty list (Name | Time | Status)
  const staffHtml = [];
  staffHtml.push('<table class="staffList"><tr><th>Name</th><th style="width:110px">Time</th><th>Status</th><th style="width:70px">&nbsp;</th></tr>');
  DB.staff.forEach(staff => {
    const name = (staff.first + ' ' + (staff.last || '')).trim();
    const time = staff.hours ? (String(staff.hours) + 'h') : '-';
    const status = (staff.position ? staff.position + (staff.ward ? ' • Ward ' + staff.ward : '') : '');
    staffHtml.push(`<tr><td><b>${name}</b></td><td>${time}</td><td class="status">${status || '-'}</td><td><button class="infoBtn" onclick="openStaffDetail('${staff.staffNo}')">ℹ️</button></td></tr>`);
  });
  staffHtml.push('</table>');
  document.getElementById('staffWidget').innerHTML = staffHtml.join('');

  let wardHtml = '<tr><th>Ward No</th><th>Name</th><th>Location</th><th>Beds</th><th>Occupied</th><th>Free</th><th>Charge Nurse</th><th>Info</th></tr>';

  DB.ward.forEach(ward => {
    const occupiedBeds = DB.patient.filter(patient => String(patient.ward) === String(ward.number) && patient.status === 'In Ward').length;
    const chargeNurse = DB.staff.find(staff => String(staff.ward) === String(ward.number) && staff.position === 'Charge Nurse');

    wardHtml += `<tr><td>${ward.number}</td><td>${ward.name}</td><td>${ward.location}</td><td>${ward.beds}</td><td>${occupiedBeds}</td><td>${ward.beds - occupiedBeds}</td><td>${chargeNurse ? chargeNurse.first + ' ' + chargeNurse.last : '-'}</td><td><button class="infoBtn" onclick="openWardDetail('${ward.number}')">ℹ️ Info</button></td></tr>`;
  });

  document.getElementById('wardOverview').innerHTML = wardHtml;

  const patientQuick = DB.patient.slice(0, 5).map(patient => `
    <tr>
      <td>${patient.patNo || '-'}</td>
      <td>${patient.first || '-'} ${patient.last || ''}</td>
      <td>${patient.status || '-'}</td>
      <td><button class="infoBtn" onclick="openPatientDetail('${patient.patNo}')">ℹ️ Info</button></td>
    </tr>
  `).join('');

  const supplierQuick = DB.supplier.map(supplier => `
    <tr>
      <td>${supplier.supNo || '-'}</td>
      <td>${supplier.name || '-'}</td>
      <td><button class="infoBtn" onclick="openSupplierDetail('${supplier.supNo}')">ℹ️ Info</button></td>
    </tr>
  `).join('');

  const medicationQuick = DB.medication.slice(0, 5).map(med => `
    <tr>
      <td>${med.patNo || '-'}</td>
      <td>${med.drugName || '-'}</td>
      <td>${med.dosage || '-'}</td>
      <td><button class="infoBtn" onclick="openMedicationDetail('${med.patNo}')">ℹ️ Info</button></td>
    </tr>
  `).join('');

  const dashboardInfo = `
    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(260px,1fr)); gap:16px; margin-top:24px;">
      <div>
        <h2>Patient Snapshot</h2>
        <table>
          <tr><th>Patient No</th><th>Name</th><th>Status</th><th>Info</th></tr>
          ${patientQuick || '<tr><td colspan="4">No patients</td></tr>'}
        </table>
      </div>
      <div>
        <h2>Supplier Directory</h2>
        <table>
          <tr><th>Supplier No</th><th>Name</th><th>Info</th></tr>
          ${supplierQuick || '<tr><td colspan="3">No suppliers</td></tr>'}
        </table>
      </div>
      <div>
        <h2>Medication Snapshot</h2>
        <table>
          <tr><th>Patient</th><th>Drug</th><th>Dose</th><th>Info</th></tr>
          ${medicationQuick || '<tr><td colspan="4">No medications</td></tr>'}
        </table>
      </div>
    </div>
  `;

  const dashboardRoot = document.getElementById('dashboard');
  if (dashboardRoot) {
    const existing = dashboardRoot.querySelector('#dashboard-info-panel');
    if (existing) existing.remove();

    const panel = document.createElement('div');
    panel.id = 'dashboard-info-panel';
    panel.innerHTML = dashboardInfo;
    dashboardRoot.appendChild(panel);
  }

  renderDashboardSlideshow();
  renderDashboardCharts();
}

// ===== Dashboard slideshow and image modal =====
