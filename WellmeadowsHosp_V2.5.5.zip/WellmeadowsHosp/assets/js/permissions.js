// ===== Role-based page & action permissions =====
// Canonical role strings (must match the `role` column in `users`
// exactly): 'Admin', 'Staff', 'Charge Nurse', 'Medical Director'.
// ('Administrator' is treated as an alias for 'Admin' so older seeded
// accounts/installs keep working without a database edit.)

// Pages every logged-in user can open regardless of role — nothing in
// the requested access rules mentioned these, so they stay open to all.
const BASE_PAGES = ['dashboard', 'beds', 'staff', 'outpatients', 'appointments', 'settings', 'profile'];

// Additional pages granted per role, on top of BASE_PAGES. Admin isn't
// listed here — it always gets every page (see canAccessPage below).
const ROLE_PAGES = {
  'Staff': ['medication', 'patients', 'wards', 'reports', 'leave', 'requisitions', 'supplies'],
  'Charge Nurse': ['medication', 'patients', 'wards', 'reports', 'leave', 'requisitions', 'supplies', 'pharma'],
  'Medical Director': ['medication', 'patients', 'wards', 'reports', 'leave', 'requisitions', 'supplies', 'pharma', 'suppliers']
};

// Roles allowed to approve/reject leave requests and requisitions.
const APPROVER_ROLES = ['Admin', 'Administrator', 'Charge Nurse', 'Medical Director'];

function isAdminRole(role) {
  return role === 'Admin' || role === 'Administrator';
}

function currentRole() {
  const user = (typeof getCurrentUser === 'function') ? getCurrentUser() : null;
  return user ? user.role : null;
}

// true = the current user may open this page. No session yet (still
// loading) always passes so the app doesn't flash a denial before we
// even know who's logged in — the auth overlay covers that case.
function canAccessPage(page) {
  const role = currentRole();
  if (!role || isAdminRole(role)) return true;
  const allowed = BASE_PAGES.concat(ROLE_PAGES[role] || []);
  return allowed.includes(page);
}

function canApprove() {
  const role = currentRole();
  return !!role && APPROVER_ROLES.includes(role);
}

function denyPermission() {
  showToast("You don't have permission.", 'error');
}

// Hides nav buttons for pages the current role can't open. Call this any
// time we learn (or re-learn) who's logged in: after the initial session
// check, after login, and after a profile save that might have changed
// the role.
function applyNavPermissions() {
  document.querySelectorAll('nav button[data-p]').forEach(btn => {
    btn.style.display = canAccessPage(btn.dataset.p) ? '' : 'none';
  });
  // If the page on screen just became off-limits (e.g. an admin changed
  // this user's role), don't leave a restricted page rendered — bounce
  // back to the dashboard, which every role can see.
  if (window.currentPage && !canAccessPage(window.currentPage)) {
    show('dashboard');
  }
}
