// ===== Dashboard analysis & printing =====
function generateDashboardAnalysis() {
  const totalBeds = DB.ward.reduce((sum, w) => sum + Number(w.beds || 0), 0);
  const occupied = DB.patient.filter(p => p.status === 'In Ward').length;
  const waiting = DB.patient.filter(p => p.status === 'Waiting List').length;
  const patients = DB.patient.length;
  const staffCount = DB.staff.length;

  const occupancyRate = totalBeds ? Math.round((occupied / totalBeds) * 100) : 0;
  const waitingPct = patients ? Math.round((waiting / patients) * 100) : 0;
  const staffToPatient = patients ? (staffCount / patients).toFixed(2) : 'N/A';

  // top 3 wards by occupancy
  const wardsWithOcc = DB.ward.map(w => {
    const occ = DB.patient.filter(p => String(p.ward) === String(w.number) && p.status === 'In Ward').length;
    return { number: w.number, name: w.name, occ, beds: Number(w.beds || 0) };
  }).map(w => ({...w, rate: w.beds ? Math.round((w.occ / w.beds) * 100) : 0}));

  wardsWithOcc.sort((a,b) => b.rate - a.rate);
  const topWards = wardsWithOcc.slice(0,3);

  const insights = [];
  if (occupancyRate > 90) insights.push('Alert: Overall bed occupancy is critically high (' + occupancyRate + '%). Consider diverting admissions or accelerating discharges.');
  else if (occupancyRate > 75) insights.push('Warning: Bed occupancy is high (' + occupancyRate + '%). Monitor capacity closely.');
  else insights.push('Bed occupancy is within normal bounds (' + occupancyRate + '%).');

  if (waitingPct > 20) insights.push('There is a significant waiting list (' + waiting + ' patients, ' + waitingPct + '% of all patients).');
  if (staffToPatient !== 'N/A' && Number(staffToPatient) < 0.2) insights.push('Staff-to-patient ratio is low (' + staffToPatient + ' staff per patient). Consider rostering review.');

  if (topWards.length) {
    insights.push('Top wards by occupancy: ' + topWards.map(w => `${w.name} (${w.rate}%)`).join(', ') + '.');
  }

  return {
    totalBeds, occupied, waiting, patients, staffCount, occupancyRate, waitingPct, staffToPatient, topWards, insights
  };
}

function compileReportHtml(options = {}) {
  const a = generateDashboardAnalysis();
  // doctor and nurse counts
  const doctorCount = (DB.staff||[]).filter(s=>/(doctor|consultant|physician)/i.test(s.position||'')).length;
  const nurseCount = (DB.staff||[]).filter(s=>/nurse/i.test(s.position||'')).length;
  const header = `<h1>Wellmeadows Dashboard Report</h1><p>Generated: ${new Date().toLocaleString()}</p>`;

  const summary = `
    <h2>Summary</h2>
    <ul>
      <li>Total patients: ${a.patients}</li>
      <li>Waiting patients: ${a.waiting}</li>
      <li>Total beds: ${a.totalBeds}</li>
      <li>Occupied beds: ${a.occupied}</li>
      <li>Available beds: ${a.totalBeds - a.occupied}</li>
      <li>Staff members: ${a.staffCount}</li>
      <li>Bed occupancy rate: ${a.occupancyRate}%</li>
      <li>Waiting as % of patients: ${a.waitingPct}%</li>
      <li>Staff-to-patient ratio: ${a.staffToPatient}</li>
      <li>Estimated wait time: ${estimateWaitTime(a.waiting)}</li>
      <li>Doctors: ${doctorCount}</li>
      <li>Nurses: ${nurseCount}</li>
    </ul>
  `;

  const insightsHtml = `<h2>Insights</h2><ul>${a.insights.map(s => `<li>${s}</li>`).join('')}</ul>`;

  const wardTableRows = DB.ward.map(w => {
    const occ = DB.patient.filter(p => String(p.ward) === String(w.number) && p.status === 'In Ward').length;
    return `<tr><td>${w.number}</td><td>${w.name}</td><td>${w.location || ''}</td><td>${w.beds}</td><td>${occ}</td><td>${w.beds - occ}</td></tr>`;
  }).join('');

  const includeWards = options.includeWards !== false;
  const includeStaff = options.includeStaff !== false;
  const includePatients = options.includePatients === true;
  const includeCharts = options.includeCharts === true;
  const includeCalendar = options.includeCalendar === true || options.includeCalendar === undefined;

  let parts = [];
  parts.push(header);
  parts.push(summary);
  parts.push(insightsHtml);

  if (includeCharts) {
    // small occupancy bar and ward bars
    const wardOcc = DB.ward.map(w => {
      const occ = DB.patient.filter(p => String(p.ward) === String(w.number) && p.status === 'In Ward').length;
      return { name: w.name, occ, beds: Number(w.beds || 0) };
    });
    parts.push(`<h2>Charts</h2>`);
    parts.push(generateBedOccupancyChartSVG(a.totalBeds, a.occupied));
    parts.push(generateWardOccupancyBarChartSVG(wardOcc));
  }

  if (includeWards) {
    const wardHtml = `<h2>Ward Overview</h2><table style="width:100%;border-collapse:collapse"><tr><th>Ward</th><th>Name</th><th>Location</th><th>Beds</th><th>Occupied</th><th>Free</th></tr>${wardTableRows}</table>`;
    parts.push(wardHtml);
  }

  if (includeStaff) {
    const staffRows = DB.staff.map(s => `<tr><td>${s.staffNo}</td><td>${s.first} ${s.last}</td><td>${s.position}</td><td>${s.ward || '-'}</td></tr>`).join('');
    const staffHtml = `<h2>Staff List</h2><table style="width:100%;border-collapse:collapse"><tr><th>Staff No</th><th>Name</th><th>Position</th><th>Ward</th></tr>${staffRows}</table>`;
    parts.push(staffHtml);
  }

  if (includePatients) {
    const patientRows = DB.patient.map(p => {
      const gender = (p.sex || p.gender || '').toString().toLowerCase();
      let bg = '';
      if (gender.startsWith('m')) bg = '#eaf4ff';
      else if (gender.startsWith('f')) bg = '#fff0f6';
      const wardName = (DB.ward.find(w=>String(w.number)===String(p.ward))||{}).name || p.ward || '';
      return `<tr style="background:${bg};color:#111"><td>${p.patNo || '-'}</td><td>${p.first || ''} ${p.last || ''}</td><td>${p.status || ''}</td><td>${wardName}</td></tr>`;
    }).join('');
    parts.push(`<h2>Patients</h2><table style="width:100%;border-collapse:collapse"><tr><th>Pat No</th><th>Name</th><th>Status</th><th>Ward</th></tr>${patientRows}</table>`);

    // Bed allocations: list occupied beds and assigned patients
    const bedAllocRows = (DB.patient || []).filter(p=>p.bed).map(p=>{
      const wardName = (DB.ward.find(w=>String(w.number)===String(p.ward))||{}).name || p.ward || '';
      return { bed: p.bed, name: (p.first||'') + ' ' + (p.last||''), status: p.status||'', ward: wardName };
    }).sort((a,b)=> Number(a.bed) - Number(b.bed)).map(r=>`<tr><td>${r.bed}</td><td>${r.name}</td><td>${r.status}</td><td>${r.ward}</td></tr>`).join('');
    if (bedAllocRows.length) parts.push(`<h2>Bed Allocations</h2><table style="width:100%;border-collapse:collapse"><tr><th>Bed No</th><th>Patient</th><th>Status</th><th>Ward</th></tr>${bedAllocRows}</table>`);

    // Staff allocations grouped by ward
    const staffByWard = {};
    (DB.staff||[]).forEach(s=>{
      const key = s.ward || 'Unassigned';
      if (!staffByWard[key]) staffByWard[key]=[];
      staffByWard[key].push((s.first||'') + ' ' + (s.last||'') + (s.position ? ' ('+s.position+')' : ''));
    });
    const staffAllocRows = Object.keys(staffByWard).map(k=>{
      const wardName = (DB.ward.find(w=>String(w.number)===String(k))||{}).name || (k==='Unassigned'? 'Unassigned' : k);
      const list = staffByWard[k].join(', ');
      return `<tr><td>${wardName}</td><td>${staffByWard[k].length}</td><td>${list}</td></tr>`;
    }).join('');
    if (staffAllocRows) parts.push(`<h2>Staff Allocations</h2><table style="width:100%;border-collapse:collapse"><tr><th>Ward</th><th>Staff Count</th><th>Staff Members</th></tr>${staffAllocRows}</table>`);
  }

  if (includeCalendar) {
    parts.push(`<h2>Calendar / Events</h2>`);
    parts.push(generateCalendarHtml());
  }

  // discover current user for footer
  let userDisplay = 'Unknown';
  try {
    const s = sessionStorage.getItem('wmSession');
    if (s) {
      const cur = JSON.parse(s);
      userDisplay = (cur.fullName || cur.user || cur.username) || userDisplay;
    }
  } catch (e) {}

  const footer = `<div style="margin-top:18px;border-top:1px solid #ddd;padding-top:8px;color:#555;font-size:12px">Printed by: ${userDisplay} — ${new Date().toLocaleString()}</div>`;

  return `
    <div style="font-family:Arial, Helvetica, sans-serif;color:#111">
      ${parts.join('\n')}
      ${footer}
    </div>
  `;
}
function printDashboardReport(options = {}) {
  const html = compileReportHtml(options);
  const w = window.open('', '_blank', 'width=900,height=700');
  if (!w) { alert('Pop-up blocked. Please allow popups to print reports.'); return; }
  w.document.write('<!doctype html><html><head><title>Dashboard Report</title>');
  w.document.write('<style>body{font-family:Arial,Helvetica,sans-serif;padding:18px}h1{color:#0b3d91}h2{color:#333}table,th,td{border:1px solid #ddd;padding:8px}th{background:#f4f4f4}svg{max-width:100%;height:auto}</style>');
  w.document.write('</head><body>');
  w.document.write(html);
  w.document.write('</body></html>');
  w.document.close();
  w.focus();
  setTimeout(()=>{ w.print(); /* w.close(); */ }, 400);
}

