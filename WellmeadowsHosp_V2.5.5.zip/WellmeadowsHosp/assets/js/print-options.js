function showPrintOptions() {
  // build modal
  const printLinkEl = document.querySelector('.printLink');
  if (printLinkEl) printLinkEl.classList.add('active');
  const overlay = document.createElement('div');
  overlay.id = 'printOptionsOverlay';
  overlay.style = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:9999';
  const box = document.createElement('div');
  box.style = 'background:#fff;padding:18px;border-radius:8px;min-width:320px;max-width:420px;color:#111';
  box.innerHTML = `
    <h3 style="margin-top:0">Print Options</h3>
    <label><input type="checkbox" id="optWards" checked> Include Ward Overview</label><br>
    <label><input type="checkbox" id="optStaff" checked> Include Staff List</label><br>
    <label><input type="checkbox" id="optPatients"> Include Patient List</label><br>
    <label><input type="checkbox" id="optCharts" checked> Include Charts</label><br>
    <label><input type="checkbox" id="optCalendar" checked> Include Calendar / Events</label>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px">
      <button id="optCancel" class="act secondary">Cancel</button>
      <button id="optPrint" class="act">Print</button>
    </div>
  `;
  overlay.appendChild(box);
  document.body.appendChild(overlay);
  document.getElementById('optCancel').onclick = ()=> { overlay.remove(); if (printLinkEl) printLinkEl.classList.remove('active'); };
  document.getElementById('optPrint').onclick = ()=>{
    const options = {
      includeWards: document.getElementById('optWards').checked,
      includeStaff: document.getElementById('optStaff').checked,
      includePatients: document.getElementById('optPatients').checked,
      includeCharts: document.getElementById('optCharts').checked,
      includeCalendar: document.getElementById('optCalendar').checked
    };
    overlay.remove();
    if (printLinkEl) printLinkEl.classList.remove('active');
    printDashboardReport(options);
  };
}

