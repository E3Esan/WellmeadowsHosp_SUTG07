// ===== Dashboard charts (Chart.js) =====
// renderDash() (dashboard-render.js) calls renderDashboardCharts() at the end
// of every dashboard render, so these always reflect the live DB data.
const CHART_REGISTRY = {};

function renderChart(canvasId, config) {
  const canvas = document.getElementById(canvasId);
  if (!canvas || typeof Chart === 'undefined') return;

  if (CHART_REGISTRY[canvasId]) {
    CHART_REGISTRY[canvasId].destroy();
  }
  CHART_REGISTRY[canvasId] = new Chart(canvas.getContext('2d'), config);
}

const CHART_PALETTE = ['#005EB8', '#61b878', '#f0a63a', '#c0392b', '#8b6eb4', '#2b7bd3', '#c9a227', '#6c757d'];

function isDarkMode() {
  return document.body.classList.contains('dark-mode');
}

function chartTextColor() {
  return isDarkMode() ? '#dce6f2' : '#22303f';
}

function renderDashboardCharts() {
  if (typeof Chart === 'undefined') return; // Chart.js CDN not reachable — dashboard still works without it
  const textColor = chartTextColor();
  Chart.defaults.color = textColor;
  Chart.defaults.font.family = "'Segoe UI', Arial, sans-serif";

  // ---- Bed occupancy (doughnut) ----
  const totalBeds = DB.ward.reduce((sum, w) => sum + Number(w.beds || 0), 0);
  const occupied = DB.patient.filter(p => p.status === 'In Ward').length;
  renderChart('chartBedOccupancy', {
    type: 'doughnut',
    data: {
      labels: ['Occupied', 'Free'],
      datasets: [{ data: [occupied, Math.max(0, totalBeds - occupied)], backgroundColor: [CHART_PALETTE[3], CHART_PALETTE[1]] }]
    },
    options: { plugins: { legend: { position: 'bottom' } }, cutout: '65%' }
  });

  // ---- Patients by status (bar) ----
  const statusCounts = {};
  DB.patient.forEach(p => { const s = p.status || 'Unknown'; statusCounts[s] = (statusCounts[s] || 0) + 1; });
  renderChart('chartPatientStatus', {
    type: 'bar',
    data: {
      labels: Object.keys(statusCounts),
      datasets: [{ label: 'Patients', data: Object.values(statusCounts), backgroundColor: CHART_PALETTE[0] }]
    },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
  });

  // ---- Staff by position (pie) ----
  const posCounts = {};
  DB.staff.forEach(s => { const p = s.position || 'Other'; posCounts[p] = (posCounts[p] || 0) + 1; });
  renderChart('chartStaffPosition', {
    type: 'pie',
    data: {
      labels: Object.keys(posCounts),
      datasets: [{ data: Object.values(posCounts), backgroundColor: CHART_PALETTE }]
    },
    options: { plugins: { legend: { position: 'bottom' } } }
  });

  // ---- Ward occupancy (horizontal bar: beds vs occupied) ----
  const wardLabels = DB.ward.map(w => `Ward ${w.number}`);
  const wardBeds = DB.ward.map(w => Number(w.beds || 0));
  const wardOcc = DB.ward.map(w => DB.patient.filter(p => String(p.ward) === String(w.number) && p.status === 'In Ward').length);
  renderChart('chartWardOccupancy', {
    type: 'bar',
    data: {
      labels: wardLabels,
      datasets: [
        { label: 'Total Beds', data: wardBeds, backgroundColor: CHART_PALETTE[5] },
        { label: 'Occupied', data: wardOcc, backgroundColor: CHART_PALETTE[3] }
      ]
    },
    options: { indexAxis: 'y', scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } }
  });

  // ---- Stock vs reorder level (supplies + pharma combined) ----
  const stockItems = [
    ...DB.supply.map(s => ({ name: s.name, qty: Number(s.qty || 0), reorder: Number(s.reorder || 0) })),
    ...DB.pharma.map(p => ({ name: p.name, qty: Number(p.qty || 0), reorder: Number(p.reorder || 0) }))
  ].slice(0, 10);
  renderChart('chartStockLevels', {
    type: 'bar',
    data: {
      labels: stockItems.map(i => i.name),
      datasets: [
        { label: 'In Stock', data: stockItems.map(i => i.qty), backgroundColor: CHART_PALETTE[1] },
        { label: 'Reorder Level', data: stockItems.map(i => i.reorder), backgroundColor: CHART_PALETTE[2] }
      ]
    },
    options: { scales: { y: { beginAtZero: true } }, plugins: { legend: { position: 'bottom' } } }
  });

  // ---- Requisitions by status (doughnut) ----
  const reqCounts = {};
  DB.requisition.forEach(r => { const s = r.status || 'Pending'; reqCounts[s] = (reqCounts[s] || 0) + 1; });
  renderChart('chartRequisitionStatus', {
    type: 'doughnut',
    data: {
      labels: Object.keys(reqCounts),
      datasets: [{ data: Object.values(reqCounts), backgroundColor: [CHART_PALETTE[2], CHART_PALETTE[1], CHART_PALETTE[3], CHART_PALETTE[4]] }]
    },
    options: { plugins: { legend: { position: 'bottom' } }, cutout: '55%' }
  });
}
