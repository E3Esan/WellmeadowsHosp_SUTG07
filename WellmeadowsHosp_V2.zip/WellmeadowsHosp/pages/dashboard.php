<?php // Page: dashboard (rendered inside <main> in index.php) ?>
  <div id="dashboard" class="page">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
      <h2>Dashboard</h2>
      <div>
        <a class="printLink" onclick="showPrintOptions()" role="button" style="cursor:pointer">Print Report</a>
      </div>
    </div>
    <div class="cards" id="dashCards"></div>

    <h2>At a Glance</h2>
    <div class="chartsGrid">
      <div class="chartCard"><h3>Bed Occupancy</h3><canvas id="chartBedOccupancy"></canvas></div>
      <div class="chartCard"><h3>Patients by Status</h3><canvas id="chartPatientStatus"></canvas></div>
      <div class="chartCard"><h3>Staff by Position</h3><canvas id="chartStaffPosition"></canvas></div>
      <div class="chartCard"><h3>Ward Occupancy</h3><canvas id="chartWardOccupancy"></canvas></div>
      <div class="chartCard"><h3>Stock vs Reorder Level</h3><canvas id="chartStockLevels"></canvas></div>
      <div class="chartCard"><h3>Requisitions by Status</h3><canvas id="chartRequisitionStatus"></canvas></div>
    </div>

  <h2>Staff on Duty</h2><div class="staffWidget" id="staffWidget"></div>
  <h2>Wards Overview</h2><table id="wardOverview"></table>
  <div id="dashboardSlideshow" class="dashboardSlideshow" aria-label="Hospital gallery slideshow"></div>
  </div>

  <!-- Bed page -->
