<?php
// ============================================================
// Generic CRUD endpoint for every data table (not `users` — that has its
// own endpoint, auth.php, so password hashes are never exposed here).
//
//   GET    table.php?table=ward                -> list all rows
//   GET    table.php?table=ward&q=cardio        -> simple search across columns
//   POST   table.php?table=ward   (JSON body)   -> insert a row, returns new row incl. id
//   PUT    table.php?table=ward&id=5 (JSON body)-> update a row
//   DELETE table.php?table=ward&id=5            -> delete a row
//
// `key=leave` in the URL maps to the `leave_request` table (MySQL reserves
// the word LEAVE), everything else maps 1:1 to a table of the same name.
// ============================================================

require __DIR__ . '/db.php';

// Whitelist: table key => [real table name, allowed columns]. This is what
// stops a caller from reading/writing arbitrary tables or columns.
$TABLES = [
    'ward'        => ['ward', ['number','name','location','beds','extn']],
    'staff'       => ['staff', ['staffNo','first','last','address','tel','dob','sex','nin','position','salary','scale','ward','hours','contract','pay','qual','institution','workExperience','medicalRecord','photo','fileName','file']],
    'patient'     => ['patient', ['patNo','first','last','address','tel','dob','sex','marital','kinName','kinRel','localDoctor','allergies','medicalRecord','ward','bed','waitDate','placedDate','expLeave','actualLeave','status','priority','refDocName','refDoc','fileName','file']],
    'outpatient'  => ['outpatient', ['patNo','first','last','address','tel','dob','sex','localDoctor','apptDate','apptTime','refDocName','refDoc','fileName','file']],
    'appointment' => ['appointment', ['apptNo','patNo','consultant','staffNo','date','time','room','referral','reason','localDoctor','fee','taxRate','paymentStatus','total','uploadedAt','refDocName','refDoc','fileName','file']],
    'medication'  => ['medication', ['patNo','patName','ward','bed','drugNo','drugName','dosage','method','units','start','finish']],
    'supply'      => ['supply', ['itemNo','name','desc','qty','reorder','cost','taxRate','paymentStatus','total','uploadedAt','photo','fileName','file']],
    'pharma'      => ['pharma', ['drugNo','name','desc','dosage','method','qty','reorder','cost','category','uses','sideEffects','warnings','photo','fileName','file']],
    'requisition' => ['requisition', ['reqNo','requestedBy','ward','itemNo','itemName','dosage','method','cost','qty','subtotal','tax','total','status','date','uploadedAt','approvedAt','fileName','file']],
    'supplier'    => ['supplier', ['supNo','name','address','tel','fax','photo','fileName','file']],
    'bedQueue'    => ['bedQueue', ['patientNo','patientName','ward','priority','status','requestedAt','admittedAt']],
    'leave'       => ['leave_request', ['leaveNo','staffNo','staffName','ward','type','startDate','endDate','reason','status','approvedBy','requestedAt']],
];

$key = $_GET['table'] ?? '';
if (!isset($TABLES[$key])) {
    send(['error' => 'Unknown or disallowed table: ' . $key], 400);
}
[$table, $cols] = $TABLES[$key];
$method = $_SERVER['REQUEST_METHOD'];
$colList = implode(',', array_map(fn($c) => "`$c`", $cols));

// Empty-string dates/numbers become NULL so MySQL doesn't reject them.
function cleanValue($v) {
    return ($v === '' || $v === null) ? null : $v;
}

if ($method === 'GET') {
    $q = trim($_GET['q'] ?? '');
    if ($q !== '') {
        $like = '%' . $q . '%';
        $stmt = $pdo->prepare("SELECT id, $colList FROM `$table` WHERE " .
            implode(' OR ', array_map(fn($c) => "`$c` LIKE ?", $cols)) . " ORDER BY id");
        $stmt->execute(array_fill(0, count($cols), $like));
    } else {
        $stmt = $pdo->prepare("SELECT id, $colList FROM `$table` ORDER BY id");
        $stmt->execute();
    }
    send($stmt->fetchAll());
}

if ($method === 'POST') {
    require_login();
    $data = body();
    $insertCols = [];
    $placeholders = [];
    $values = [];
    foreach ($cols as $c) {
        if (array_key_exists($c, $data)) {
            $insertCols[] = "`$c`";
            $placeholders[] = '?';
            $values[] = cleanValue($data[$c]);
        }
    }
    if (empty($insertCols)) send(['error' => 'No valid columns supplied'], 400);
    $sql = "INSERT INTO `$table` (" . implode(',', $insertCols) . ") VALUES (" . implode(',', $placeholders) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($values);
    $newId = $pdo->lastInsertId();
    $get = $pdo->prepare("SELECT id, $colList FROM `$table` WHERE id = ?");
    $get->execute([$newId]);
    send($get->fetch(), 201);
}

if ($method === 'PUT') {
    require_login();
    $id = $_GET['id'] ?? null;
    if (!$id) send(['error' => 'Missing id'], 400);
    $data = body();
    $setParts = [];
    $values = [];
    foreach ($cols as $c) {
        if (array_key_exists($c, $data)) {
            $setParts[] = "`$c` = ?";
            $values[] = cleanValue($data[$c]);
        }
    }
    if (empty($setParts)) send(['error' => 'No valid columns supplied'], 400);
    $values[] = $id;
    $sql = "UPDATE `$table` SET " . implode(',', $setParts) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($values);
    $get = $pdo->prepare("SELECT id, $colList FROM `$table` WHERE id = ?");
    $get->execute([$id]);
    send($get->fetch());
}

if ($method === 'DELETE') {
    require_login();
    $id = $_GET['id'] ?? null;
    if (!$id) send(['error' => 'Missing id'], 400);
    $stmt = $pdo->prepare("DELETE FROM `$table` WHERE id = ?");
    $stmt->execute([$id]);
    send(['ok' => true]);
}

send(['error' => 'Method not allowed'], 405);
