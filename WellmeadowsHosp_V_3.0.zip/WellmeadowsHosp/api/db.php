<?php
// ============================================================
// Database connection (XAMPP/Laragon defaults: host=localhost, user=root,
// no password). If your setup differs (MAMP, shared hosting, etc.), edit
// the four values below — nothing else in this file needs to change.
// ============================================================

$DB_HOST = 'localhost';
$DB_NAME = 'wellmeadows';
$DB_USER = 'root';
$DB_PASS = '';

// Same-origin only: the frontend and this API are served from the same
// domain, so no cross-origin header is needed here.
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Database connection failed: ' . $e->getMessage(),
        'hint'  => 'Check $DB_HOST/$DB_NAME/$DB_USER/$DB_PASS in api/db.php, and make sure you imported sql/DatabaseG07.sql in phpMyAdmin.',
    ]);
    exit;
}

// Session for login state (used by auth.php + require_login() below)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function send($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function body() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// Require an active session for actions that change data (POST/PUT/DELETE).
// Reads stay open so the dashboard/reports can be viewed without a fuss,
// matching this project's original scope — see README for the note on
// adding per-role permissions before this ever holds real patient data.
function require_login() {
    if (empty($_SESSION['wmUser'])) {
        send(['error' => 'You must be logged in to do that.'], 401);
    }
    return $_SESSION['wmUser'];
}

function current_user() {
    return $_SESSION['wmUser'] ?? null;
}

// Mirrors isAdminRole() in assets/js/permissions.js — keep both in sync.
// 'Administrator' is treated as an alias of 'Admin' for older seeded accounts.
function is_admin_role($role) {
    return $role === 'Admin' || $role === 'Administrator';
}

// Require an active session AND an Admin/Administrator role. Used by
// api/users.php so only admins can list every account or edit someone
// else's sensitive info (role, email, phone, etc.).
function require_admin() {
    $me = require_login();
    if (!is_admin_role($me['role'] ?? '')) {
        send(['error' => "You don't have permission. Admins only."], 403);
    }
    return $me;
}
