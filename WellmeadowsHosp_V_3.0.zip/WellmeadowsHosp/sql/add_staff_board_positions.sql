-- Add saved dashboard board coordinates to an existing Wellmeadows database.
-- Coordinates are percentages within the staff member's ward space.

ALTER TABLE staff
  ADD COLUMN IF NOT EXISTS boardX DECIMAL(6,2) NULL,
  ADD COLUMN IF NOT EXISTS boardY DECIMAL(6,2) NULL;