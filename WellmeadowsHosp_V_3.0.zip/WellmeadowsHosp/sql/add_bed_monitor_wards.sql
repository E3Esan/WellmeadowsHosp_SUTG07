-- Add the full bed-monitor ward set to an existing Wellmeadows database.
-- Existing patient bed assignments are preserved. Ward 11 has seeded occupied
-- bed numbers in the 80s, so its capacity must cover bed 87 as well as the
-- normal minimum of 20 beds.

INSERT INTO ward (number, name, location, beds, extn)
SELECT 1, 'Emergency', 'Main Building', 20, '7701' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 1);
INSERT INTO ward (number, name, location, beds, extn)
SELECT 2, 'Medical', 'Main Building', 20, '7702' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 2);
INSERT INTO ward (number, name, location, beds, extn)
SELECT 3, 'Surgical', 'Main Building', 20, '7703' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 3);
INSERT INTO ward (number, name, location, beds, extn)
SELECT 4, 'Paediatric', 'North Wing', 20, '7704' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 4);
INSERT INTO ward (number, name, location, beds, extn)
SELECT 5, 'Maternity', 'North Wing', 20, '7705' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 5);
INSERT INTO ward (number, name, location, beds, extn)
SELECT 6, 'Oncology', 'North Wing', 20, '7706' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 6);
INSERT INTO ward (number, name, location, beds, extn)
SELECT 7, 'Neurology', 'South Wing', 20, '7707' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 7);
INSERT INTO ward (number, name, location, beds, extn)
SELECT 8, 'Intensive Care Unit', 'South Wing', 20, '7708' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 8);
INSERT INTO ward (number, name, location, beds, extn)
SELECT 9, 'Rehabilitation', 'South Wing', 20, '7709' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 9);
INSERT INTO ward (number, name, location, beds, extn)
SELECT 10, 'Geriatric', 'South Wing', 20, '7710' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM ward WHERE number = 10);

UPDATE ward SET beds = GREATEST(beds, 87) WHERE number = 11;
UPDATE ward SET beds = GREATEST(beds, 20) WHERE number = 12;