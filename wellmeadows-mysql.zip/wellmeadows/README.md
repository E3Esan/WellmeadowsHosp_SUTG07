# Wellmeadows Hospital System — MySQL / phpMyAdmin setup

Two common local setups both work the same way: **XAMPP** or **Laragon**. Pick
whichever you have.

## Option A — XAMPP

### 1. Install & start XAMPP
Download from https://www.apachefriends.org if you don't have it, then open the
**XAMPP Control Panel** and click **Start** next to both **Apache** and **MySQL**.

### 2. Copy this folder into htdocs
Copy the whole `wellmeadows` folder into your XAMPP `htdocs` directory, e.g.:

- Windows: `C:\xampp\htdocs\wellmeadows`
- macOS: `/Applications/XAMPP/htdocs/wellmeadows`

You should end up with `htdocs/wellmeadows/index.html`, `htdocs/wellmeadows/api/...`, etc.

### 3. Create the database with phpMyAdmin
1. Open **http://localhost/phpmyadmin**
2. Click **Import** in the top menu
3. Click **Choose File**, select `sql/schema.sql` from this folder
4. Click **Go** at the bottom

### 4. Open the app
Go to **http://localhost/wellmeadows/**.

## Option B — Laragon

### 1. Install & start Laragon
Download from https://laragon.org/download if you don't have it. Open Laragon
and click **Start All** (starts Apache/Nginx + MySQL together).

### 2. Copy this folder into www
Copy the whole `wellmeadows` folder into Laragon's `www` directory, e.g.:

- `C:\laragon\www\wellmeadows`

Laragon auto-detects folders in `www` and can give you a pretty URL like
`http://wellmeadows.test` (via its "Auto Virtual Hosts" feature) — or you can
just use `http://localhost/wellmeadows/` the same as XAMPP.

### 3. Create the database with phpMyAdmin
Right-click the Laragon tray icon → **Database** (or **MySQL** → **phpMyAdmin**,
depending on your Laragon version) to open phpMyAdmin. Same as XAMPP from here:
**Import** tab → choose `sql/schema.sql` → **Go**.

Laragon's MySQL defaults are the same as XAMPP's: host `localhost`, user `root`,
no password — so `api/db.php` needs no changes.

### 4. Open the app
Go to **http://localhost/wellmeadows/** (or `http://wellmeadows.test` if you set
up the virtual host).

## Either way, once it's running
This creates a `wellmeadows` database with all the tables (ward, staff, patient,
medication, supplies, etc.) and loads the same seed data the prototype started with,
plus a `users` table with one login:

- **username:** `admin`
- **password:** `admin123`

## Check the database connection settings
Open `api/db.php`. The defaults match a stock XAMPP or Laragon install:

```php
$DB_HOST = 'localhost';
$DB_NAME = 'wellmeadows';
$DB_USER = 'root';
$DB_PASS = '';
```

If your MySQL root user has a password, or you're on MAMP (which often uses
port 8889 and user `root`/pass `root`), update these values. Log in with
`admin` / `admin123`. From here on, every add/delete you do in the app is a real
row in MySQL — you can see it update live in phpMyAdmin's **Browse** tab for
each table.

## How it fits together

```
index.html  --fetch()-->  api/table.php  --PDO-->  MySQL "wellmeadows" DB
index.html  --fetch()-->  api/auth.php   --PDO-->  MySQL "users" table
```

- `api/db.php` — shared DB connection + small JSON helpers, included by the other two.
- `api/table.php` — one generic endpoint for every data table (ward, staff, patient,
  medication, supply, pharma, requisition, supplier, outpatient, appointment).
  Table and column names are whitelisted, so it can't be pointed at arbitrary tables.
- `api/auth.php` — login/register/logout/session-check. Passwords are hashed with
  PHP's `password_hash()` — never stored or sent back in plain text.

## Going from localhost to a real web host

The same code works on shared hosting (Hostinger, Namecheap, SiteGround, GoDaddy,
etc.) — almost all of them give you cPanel, which bundles phpMyAdmin the same way
XAMPP does. Steps:

1. **Create the database** — in cPanel, use "MySQL Databases" (or just open
   phpMyAdmin from cPanel directly) to create a database. Shared hosts usually
   prefix everything with your account username, e.g. `myuser_wellmeadows`
   instead of `wellmeadows` — note the exact name it gives you.
2. **Import the schema** — open phpMyAdmin, select that database, Import tab,
   choose `sql/schema.sql`, Go. Same as the local steps.
3. **Update `api/db.php`** — set `$DB_NAME`, `$DB_USER`, `$DB_PASS` to the values
   your host gave you. `$DB_HOST` is almost always still `'localhost'` even
   though you're "on the internet" — the PHP script runs on the same server as
   MySQL, it's just the browser that's remote.
4. **Upload the files** — via cPanel's File Manager or FTP, into `public_html`
   (or a subfolder like `public_html/wellmeadows`) instead of `htdocs`.
5. **Visit your domain** — e.g. `https://yourdomain.com/wellmeadows/`.

### A few things that matter once this is public instead of localhost-only
- `api/db.php` now only sends CORS headers for same-origin requests (removed the
  wildcard `Access-Control-Allow-Origin: *`) — no reason to let other websites
  call your API once it's on the open internet.
- `sql/.htaccess` blocks direct downloads of `schema.sql` if it ends up inside
  your web root — the seed data itself isn't sensitive, but there's no reason to
  serve raw SQL files publicly.
- Turn on **HTTPS** (most hosts offer a free Let's Encrypt certificate in cPanel)
  before anyone logs in for real — right now the login POSTs a password over
  plain `fetch()`, which is fine on `localhost` but should be encrypted in transit
  once it leaves your machine.
- There's still no per-role permission check on the API (see the note above) —
  worth adding before this holds real patient data, even for a class project demo.
- Consider lowering `display_errors` / turning off PHP error output on the live
  site (most hosts default this off already) so a DB error never leaks connection
  details to a visitor.

## Other notes
- File uploads are stored as base64 text directly in the DB (`LONGTEXT` columns) to
  keep things simple, matching how the prototype handled them. For real use, storing
  files on disk (or object storage) and keeping just a path in the DB scales better.
- The weekly shift rota shown in the Ward info popup is still generated on the fly
  in the browser (there's no real rota data/table) — let me know if you want that
  turned into a real `shift` table too.
