<?php
// ============================================================
// Database connection (XAMPP defaults: host=localhost, user=root, no password)
// If your setup differs, edit the values below.
// ============================================================

$DB_HOST = 'localhost';
$DB_NAME = 'wellmeadows';
$DB_USER = 'root';
$DB_PASS = '';

// Same-origin only. The frontend and this API are served from the same domain,
// so no cross-origin header is needed. (Remove/loosen only if you split the
// frontend onto a different domain than the API.)
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

// Start a session for login state (used by auth.php)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function send($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function body() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}
