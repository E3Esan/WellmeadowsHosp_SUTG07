<?php
// ============================================================
// Auth endpoint. Passwords are hashed with password_hash() - never stored
// or returned in plain text.
//
// Usage (JSON body for login/register):
//   POST auth.php?action=login    {user, pass}
//   POST auth.php?action=register {user, pass, role}
//   POST auth.php?action=logout
//   GET  auth.php?action=session   -> current logged-in user, or null
// ============================================================

require __DIR__ . '/db.php';

$action = $_GET['action'] ?? '';

if ($action === 'session') {
    send(['user' => $_SESSION['wmUser'] ?? null]);
}

if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = body();
    $user = trim($data['user'] ?? '');
    $pass = $data['pass'] ?? '';

    $stmt = $pdo->prepare("SELECT id, user, pass, role FROM users WHERE user = ?");
    $stmt->execute([$user]);
    $row = $stmt->fetch();

    if (!$row || !password_verify($pass, $row['pass'])) {
        send(['error' => 'Invalid username or password'], 401);
    }

    $sessionUser = ['id' => $row['id'], 'user' => $row['user'], 'role' => $row['role']];
    $_SESSION['wmUser'] = $sessionUser;
    send(['user' => $sessionUser]);
}

if ($action === 'register' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = body();
    $user = trim($data['user'] ?? '');
    $pass = $data['pass'] ?? '';
    $role = $data['role'] ?? 'Personnel Officer';

    if ($user === '' || $pass === '') {
        send(['error' => 'Username and password required'], 400);
    }

    $check = $pdo->prepare("SELECT id FROM users WHERE user = ?");
    $check->execute([$user]);
    if ($check->fetch()) {
        send(['error' => 'Username already exists'], 409);
    }

    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (user, pass, role) VALUES (?, ?, ?)");
    $stmt->execute([$user, $hash, $role]);
    send(['ok' => true], 201);
}

if ($action === 'logout') {
    unset($_SESSION['wmUser']);
    session_destroy();
    send(['ok' => true]);
}

send(['error' => 'Unknown action'], 400);
