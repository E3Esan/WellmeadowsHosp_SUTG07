<?php
// ============================================================
// Generic CRUD endpoint for every data table (not the users table -
// that has its own endpoint, auth.php, so passwords are never exposed here).
//
// Usage:
//   GET    table.php?table=ward                -> list all rows
//   GET    table.php?table=ward&q=cardio        -> simple search across columns
//   POST   table.php?table=ward   (JSON body)   -> insert a row, returns new row incl. id
//   PUT    table.php?table=ward&id=5 (JSON body)-> update a row
//   DELETE table.php?table=ward&id=5            -> delete a row
// ============================================================

require __DIR__ . '/db.php';

// Whitelist: table name => allowed columns (must match sql/schema.sql).
// This prevents callers from reading/writing arbitrary tables or columns.
$COLUMNS = [
    'ward'        => ['number','name','location','beds','extn'],
    'staff'       => ['staffNo','first','last','address','tel','dob','sex','nin','position','salary','scale','ward','hours','contract','pay','qual','institution','photo','fileName','file'],
    'patient'     => ['patNo','first','last','address','tel','dob','sex','marital','kinName','kinRel','ward','bed','waitDate','placedDate','expLeave','actualLeave','status','fileName','file'],
    'outpatient'  => ['patNo','first','last','address','tel','dob','sex','apptDate','apptTime','fileName','file'],
    'appointment' => ['apptNo','patNo','consultant','staffNo','date','time','room','fileName','file'],
    'medication'  => ['patNo','patName','ward','bed','drugNo','drugName','dosage','method','units','start','finish'],
    'supply'      => ['itemNo','name','desc','qty','reorder','cost'],
    'pharma'      => ['drugNo','name','desc','dosage','method','qty','reorder','cost'],
    'requisition' => ['reqNo','requestedBy','ward','itemNo','itemName','dosage','method','cost','qty','date'],
    'supplier'    => ['supNo','name','address','tel','fax'],
];

$table = $_GET['table'] ?? '';
if (!isset($COLUMNS[$table])) {
    send(['error' => 'Unknown or disallowed table: ' . $table], 400);
}
$cols = $COLUMNS[$table];
$method = $_SERVER['REQUEST_METHOD'];

// Empty-string dates/numbers become NULL so MySQL doesn't reject them.
function cleanValue($v) {
    return ($v === '') ? null : $v;
}

if ($method === 'GET') {
    $q = trim($_GET['q'] ?? '');
    if ($q !== '') {
        $like = '%' . $q . '%';
        $stmt = $pdo->prepare("SELECT id, " . implode(',', array_map(fn($c) => "`$c`", $cols)) . " FROM `$table` WHERE " .
            implode(' OR ', array_map(fn($c) => "`$c` LIKE ?", $cols)) . " ORDER BY id");
        $stmt->execute(array_fill(0, count($cols), $like));
    } else {
        $stmt = $pdo->prepare("SELECT id, " . implode(',', array_map(fn($c) => "`$c`", $cols)) . " FROM `$table` ORDER BY id");
        $stmt->execute();
    }
    send($stmt->fetchAll());
}

if ($method === 'POST') {
    $data = body();
    $insertCols = [];
    $placeholders = [];
    $values = [];
    foreach ($cols as $c) {
        if (array_key_exists($c, $data)) {
            $insertCols[] = "`$c`";
            $placeholders[] = '?';
            $values[] = cleanValue($data[$c]);
        }
    }
    if (empty($insertCols)) send(['error' => 'No valid columns supplied'], 400);
    $sql = "INSERT INTO `$table` (" . implode(',', $insertCols) . ") VALUES (" . implode(',', $placeholders) . ")";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($values);
    $newId = $pdo->lastInsertId();
    $get = $pdo->prepare("SELECT id, " . implode(',', array_map(fn($c) => "`$c`", $cols)) . " FROM `$table` WHERE id = ?");
    $get->execute([$newId]);
    send($get->fetch(), 201);
}

if ($method === 'PUT') {
    $id = $_GET['id'] ?? null;
    if (!$id) send(['error' => 'Missing id'], 400);
    $data = body();
    $setParts = [];
    $values = [];
    foreach ($cols as $c) {
        if (array_key_exists($c, $data)) {
            $setParts[] = "`$c` = ?";
            $values[] = cleanValue($data[$c]);
        }
    }
    if (empty($setParts)) send(['error' => 'No valid columns supplied'], 400);
    $values[] = $id;
    $sql = "UPDATE `$table` SET " . implode(',', $setParts) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($values);
    send(['ok' => true]);
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    if (!$id) send(['error' => 'Missing id'], 400);
    $stmt = $pdo->prepare("DELETE FROM `$table` WHERE id = ?");
    $stmt->execute([$id]);
    send(['ok' => true]);
}

send(['error' => 'Method not allowed'], 405);
