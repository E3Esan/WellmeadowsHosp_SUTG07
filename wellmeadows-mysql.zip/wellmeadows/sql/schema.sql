-- ============================================================
-- Wellmeadows Hospital System - Database Schema
-- Import this file in phpMyAdmin: Databases > Create "wellmeadows"
-- > select it > Import tab > choose this file > Go
-- ============================================================

CREATE DATABASE IF NOT EXISTS wellmeadows CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE wellmeadows;

-- ---------- users (login accounts) ----------
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user VARCHAR(50) NOT NULL UNIQUE,
  pass VARCHAR(255) NOT NULL,      -- stores a password_hash(), never plain text
  role VARCHAR(50) NOT NULL DEFAULT 'Personnel Officer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default admin login: username = admin / password = admin123
-- (hash below is password_hash('admin123', PASSWORD_DEFAULT))
INSERT INTO users (user, pass, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Medical Director');

-- ---------- ward ----------
CREATE TABLE ward (
  id INT AUTO_INCREMENT PRIMARY KEY,
  number INT NOT NULL,
  name VARCHAR(100),
  location VARCHAR(100),
  beds INT DEFAULT 0,
  extn VARCHAR(20)
);

INSERT INTO ward (number,name,location,beds,extn) VALUES
(11,'Orthopaedic','Block E',20,'7711'),
(12,'Cardiology','Block E',18,'7712');

-- ---------- staff ----------
CREATE TABLE staff (
  id INT AUTO_INCREMENT PRIMARY KEY,
  staffNo VARCHAR(20) UNIQUE,
  first VARCHAR(60),
  last VARCHAR(60),
  address VARCHAR(200),
  tel VARCHAR(30),
  dob DATE NULL,
  sex VARCHAR(10),
  nin VARCHAR(20),
  position VARCHAR(60),
  salary DECIMAL(10,2),
  scale VARCHAR(10),
  ward INT NULL,
  hours DECIMAL(5,2),
  contract VARCHAR(5),
  pay VARCHAR(5),
  qual VARCHAR(150),
  institution VARCHAR(150),
  photo VARCHAR(255),
  fileName VARCHAR(150),
  file LONGTEXT
);

INSERT INTO staff (staffNo,first,last,address,tel,dob,sex,nin,position,salary,scale,ward,hours,contract,pay,qual,institution,photo) VALUES
('S011','Moira','Samuel','49 School Road, Broxburn','01506-45633','1961-05-30','Female','WB123423D','Charge Nurse',18760,'1C',11,37.5,'P','M','BSc Nursing Studies','Edinburgh University','photos/staff2.png'),
('S098','Carol','Cummings','15 High Street Edinburgh','0131-334-5677','1975-02-14','Female','','Staff Nurse',15000,'1B',11,37.5,'P','M','','','photos/staff5.png'),
('S123','Morgan','Russell','23A George Street Broxburn','01506-67676','1980-07-01','Male','','Nurse',14000,'1A',11,37.5,'T','M','','','photos/staff4.png'),
('S167','Robin','Plevin','7 Glen Terrace Edinburgh','0131-339-6123','1978-03-22','Male','','Staff Nurse',15200,'1B',11,37.5,'P','M','','','photos/staff1.png'),
('S234','Amy',"O'Donnell",'234 Princes Street Edinburgh','0131-334-9099','1985-11-09','Female','','Nurse',14000,'1A',11,37.5,'P','M','','',''),
('S344','Laurence','Burns','1 Apple Drive Edinburgh','0131-334-9100','1970-01-15','Male','','Consultant',45000,'CON',11,40,'P','M','MD','Edinburgh University','photos/staff3.png');

-- ---------- patient ----------
CREATE TABLE patient (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patNo VARCHAR(20),
  first VARCHAR(60),
  last VARCHAR(60),
  address VARCHAR(200),
  tel VARCHAR(30),
  dob DATE NULL,
  sex VARCHAR(10),
  marital VARCHAR(20),
  kinName VARCHAR(100),
  kinRel VARCHAR(50),
  ward INT NULL,
  bed INT NULL,
  waitDate DATE NULL,
  placedDate DATE NULL,
  expLeave DATE NULL,
  actualLeave DATE NULL,
  status VARCHAR(30),
  fileName VARCHAR(150),
  file LONGTEXT
);

INSERT INTO patient (patNo,first,last,address,tel,dob,sex,marital,kinName,kinRel,ward,bed,waitDate,placedDate,expLeave,actualLeave,status) VALUES
('P10451','Robert','Drumtree','','',NULL,'','','','',11,84,'2004-01-12','2004-01-12','2004-01-17','2004-01-16','Discharged'),
('P10480','Steven','Parks','','',NULL,'','','','',11,79,'2004-01-12','2004-01-14','2004-01-18','2004-01-18','Discharged'),
('P10563','David','Black','','',NULL,'','','','',11,80,'2004-01-13','2004-01-13','2004-01-27',NULL,'In Ward'),
('P10604','Ian','Thomson','','',NULL,'','','','',11,87,'2004-01-14','2004-01-15','2004-01-25',NULL,'In Ward'),
('P10787','Peter','Smith','','',NULL,'','','','',11,84,'2004-01-17','2004-01-17','2004-01-22',NULL,'In Ward'),
('P10234','Anne','Phelps','44 North Bridges, Cannonmills, Edinburgh EH1 5GH','0131-332-4111','1933-12-12','Female','Single','James Phelps','Son',NULL,NULL,'2004-02-21',NULL,NULL,NULL,'Waiting List');

-- ---------- outpatient ----------
CREATE TABLE outpatient (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patNo VARCHAR(20),
  first VARCHAR(60),
  last VARCHAR(60),
  address VARCHAR(200),
  tel VARCHAR(30),
  dob DATE NULL,
  sex VARCHAR(10),
  apptDate DATE NULL,
  apptTime TIME NULL,
  fileName VARCHAR(150),
  file LONGTEXT
);

-- ---------- appointment ----------
CREATE TABLE appointment (
  id INT AUTO_INCREMENT PRIMARY KEY,
  apptNo VARCHAR(20),
  patNo VARCHAR(20),
  consultant VARCHAR(100),
  staffNo VARCHAR(20),
  date DATE NULL,
  time TIME NULL,
  room VARCHAR(30),
  fileName VARCHAR(150),
  file LONGTEXT
);

-- ---------- medication ----------
CREATE TABLE medication (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patNo VARCHAR(20),
  patName VARCHAR(100),
  ward INT NULL,
  bed INT NULL,
  drugNo INT NULL,
  drugName VARCHAR(100),
  dosage VARCHAR(50),
  method VARCHAR(30),
  units INT NULL,
  start DATE NULL,
  finish DATE NULL
);

INSERT INTO medication (patNo,patName,ward,bed,drugNo,drugName,dosage,method,units,start,finish) VALUES
('P10034','Robert MacDonald',11,84,10223,'Morphine','10mg/ml','Oral',50,'2004-03-24','2004-04-24'),
('P10034','Robert MacDonald',11,84,10334,'Tetracycline','0.5mg/ml','IV',10,'2004-03-24','2004-04-17'),
('P10034','Robert MacDonald',11,84,10223,'Morphine','10mg/ml','Oral',10,'2004-04-25','2004-05-02');

-- ---------- supply ----------
CREATE TABLE supply (
  id INT AUTO_INCREMENT PRIMARY KEY,
  itemNo VARCHAR(20),
  name VARCHAR(100),
  `desc` VARCHAR(200),
  qty INT,
  reorder INT,
  cost DECIMAL(10,2)
);

INSERT INTO supply (itemNo,name,`desc`,qty,reorder,cost) VALUES
('IT001','Syringes','Sterile disposable syringes',500,100,0.15),
('IT002','Sterile Dressings','Wound dressing pads',300,50,0.80),
('IT003','Plastic Bags','Non-surgical clinical waste bags',1000,200,0.05),
('IT004','Aprons','Disposable plastic aprons',600,150,0.10);

-- ---------- pharma ----------
CREATE TABLE pharma (
  id INT AUTO_INCREMENT PRIMARY KEY,
  drugNo INT,
  name VARCHAR(100),
  `desc` VARCHAR(200),
  dosage VARCHAR(50),
  method VARCHAR(30),
  qty INT,
  reorder INT,
  cost DECIMAL(10,2)
);

INSERT INTO pharma (drugNo,name,`desc`,dosage,method,qty,reorder,cost) VALUES
(10223,'Morphine','Pain killer','10mg/ml','Oral',200,50,27.75),
(10334,'Tetracycline','Antibiotic','0.5mg/ml','IV',150,40,12.50);

-- ---------- requisition ----------
CREATE TABLE requisition (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reqNo VARCHAR(20),
  requestedBy VARCHAR(100),
  ward INT NULL,
  itemNo VARCHAR(20),
  itemName VARCHAR(100),
  dosage VARCHAR(50),
  method VARCHAR(30),
  cost DECIMAL(10,2),
  qty INT,
  date DATE NULL
);

INSERT INTO requisition (reqNo,requestedBy,ward,itemNo,itemName,dosage,method,cost,qty,date) VALUES
('034567712','Moira Samuel',11,'10223','Morphine','10mg/ml','Oral',27.75,50,'2004-02-15');

-- ---------- supplier ----------
CREATE TABLE supplier (
  id INT AUTO_INCREMENT PRIMARY KEY,
  supNo VARCHAR(20),
  name VARCHAR(100),
  address VARCHAR(200),
  tel VARCHAR(30),
  fax VARCHAR(30)
);

INSERT INTO supplier (supNo,name,address,tel,fax) VALUES
('SU01','MediSupply Ltd','12 Industrial Est, Edinburgh','0131-500-1000','0131-500-1001'),
('SU02','PharmaCorp UK','8 Fife Road, Glasgow','0141-600-2000','0141-600-2001');
