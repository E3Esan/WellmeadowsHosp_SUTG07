# Wellmeadows Hospital — split structure

This is your original single-file prototype (`wellmeadows-hospital_prototype_v1_1_2.html`,
~4,986 lines) broken into PHP includes + separate CSS/JS files. It is a
**structural split, not a rewrite**: every id, class, and function name is
unchanged, so the app behaves exactly like the prototype.

## Important: this is still a client-side app
The "database" is still the in-browser `SCHEMA`/`DB` object in
`assets/js/data.js`, persisted to `localStorage`/`sessionStorage`. Nothing
here talks to MySQL or a PHP backend yet. `.php` files are used purely as
server-side **includes** (so Apache/PHP glues the sections together into one
page at request time) — if you open `index.php` with PHP's built-in server
or on any Apache/PHP host, it will render identically to the old single file.

If your course requirement is a real PHP + MySQL backend (not just split
files), that's a separate, bigger step — happy to help with that next
(`config/db.php`, PDO connections, and rewriting `data.js`'s CRUD calls into
`fetch()` calls against PHP API endpoints). Right now this only does what
your TODO comment in the original file asked: "split code to be more
readable (php, js, css, html)."

## Image assets
`assets/js/dashboard-slideshow.js` references image paths like
`commerical_ai_pics/2d5fff2f-....png`. Put your `commerical_ai_pics/` folder
at the project root (same level as `index.php`), or move it into
`assets/images/` and update those paths in `dashboard-slideshow.js`.

## Script load order matters
The JS was one big `<script>` block using plain global `function`/`const`
declarations (no ES modules), so later files depend on earlier ones being
loaded first (e.g. `nav.js` needs `PAGES` before `crud.js`/`render-table.js`
call `show()`). `index.php` already loads them in the correct order — don't
reorder the `<script src>` tags without checking dependencies.

## Demo login
Default accounts are seeded in `assets/js/auth.js` (`DEFAULT_USERS`), same
as before — first user is `admin` / `admin123`.
