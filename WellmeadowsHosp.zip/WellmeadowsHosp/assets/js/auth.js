const DEFAULT_USERS = [
  { user: 'admin', pass: 'admin123', role: 'Administrator' },
  { user: 'Moiralnwza67', pass: 'ILoveMyDog', role: 'Charge Nurse' }

];
let USERS = JSON.parse(localStorage.getItem('wmUsers') || JSON.stringify(DEFAULT_USERS));

function saveUsers() {
  localStorage.setItem('wmUsers', JSON.stringify(USERS));
}

function toggleAuth(which) {
  document.getElementById('loginBox').style.display = which === 'login' ? 'block' : 'none';
  document.getElementById('registerBox').style.display = which === 'register' ? 'block' : 'none';
}

function updateAuthButton() {
  const stored = sessionStorage.getItem('wmSession');
  const btn = document.getElementById('authBtn');
  const userText = document.getElementById('authBtnUser');
  if (!btn || !userText) return;

  if (!stored) {
    userText.textContent = 'Login';
    btn.onclick = () => {
      document.getElementById('authOverlay').style.display = 'flex';
      toggleAuth('login');
    };
    return;
  }

  const current = JSON.parse(stored);
  const username = (current.user || 'User').trim();
  userText.textContent = username;
  btn.onclick = openUserProfile;
}

function populateProfileFields(current) {
  if (!current) return;
  const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
  const setVal = (id, value) => { const el = document.getElementById(id); if (el) el.value = value; };
  setText('profile-username', current.user || 'User');
  setText('profile-role', current.role || 'No role');
  setText('profile-user-name', current.user || '-');
  setText('profile-user-role', current.role || '-');
  setVal('profile-full-name', current.fullName || current.user || '');
  setVal('profile-email', current.email || '');
  setVal('profile-phone', current.phone || '');
  setVal('profile-current-pass', '');
  setVal('profile-new-pass', '');
  // settings inputs (if present)
  setVal('profile-username-input', current.user || '');
  const roleInput = document.getElementById('profile-role-input'); if (roleInput) roleInput.value = current.role || '';
  const pos = document.getElementById('profile-position'); if (pos) pos.value = current.position || '';
}

function openUserProfile() {
  const stored = sessionStorage.getItem('wmSession');
  if (!stored) {
    document.getElementById('authOverlay').style.display = 'flex';
    toggleAuth('login');
    return;
  }

  const current = JSON.parse(stored);
  populateProfileFields(current);
  // overlay removed — navigate to profile page if available
  const profilePage = document.getElementById('profile');
  if (profilePage) show('profile'); else console.log('userProfileOverlay removed; no profile page present');
}

function closeUserProfile() {
  const overlay = document.getElementById('userProfileOverlay');
  if (overlay) overlay.classList.remove('show');
}

function saveProfileSettings() {
  const stored = sessionStorage.getItem('wmSession');
  if (!stored) return;
  const current = JSON.parse(stored);
  const fullNameEl = document.getElementById('profile-full-name');
  const emailEl = document.getElementById('profile-email');
  const phoneEl = document.getElementById('profile-phone');
  const fullName = fullNameEl ? fullNameEl.value.trim() : (current.fullName || current.user);
  const email = emailEl ? emailEl.value.trim() : (current.email || '');
  const phone = phoneEl ? phoneEl.value.trim() : (current.phone || '');

  // additional settings fields
  const usernameEl = document.getElementById('profile-username-input');
  const roleEl = document.getElementById('profile-role-input');
  const posEl = document.getElementById('profile-position');
  const newUsername = usernameEl ? usernameEl.value.trim() : current.user;
  const newRole = roleEl ? roleEl.value : current.role;
  const newPos = posEl ? posEl.value.trim() : (current.position || '');

  // validate username uniqueness if changed
  if (newUsername && newUsername !== current.user) {
    if (USERS.find(u => u.user === newUsername)) {
      alert('Username already exists. Choose another.');
      return;
    }
  }

  const userMatch = USERS.find(user => user.user === current.user);
  if (userMatch) {
    userMatch.fullName = fullName || current.user;
    userMatch.email = email;
    userMatch.phone = phone;
    if (newUsername && newUsername !== current.user) userMatch.user = newUsername;
    if (newRole) userMatch.role = newRole;
    if (newPos) userMatch.position = newPos;
    saveUsers();
  }

  const updated = { ...current, user: newUsername || current.user, fullName: fullName || current.user, email, phone, role: newRole || current.role, position: newPos || current.position };
  sessionStorage.setItem('wmSession', JSON.stringify(updated));
  populateProfileFields(updated);
  alert('Profile information updated.');
}

function toggleProfileSettings() {
  const panel = document.getElementById('profile-settings-panel');
  const btn = document.getElementById('profile-settings-toggle');
  if (!panel || !btn) return;
  const isOpen = panel.classList.contains('open');
  panel.classList.toggle('open', !isOpen);
  btn.classList.toggle('open', !isOpen);
  btn.textContent = !isOpen ? 'Close' : 'Open';
}

function renderProfilePage() {
  const stored = sessionStorage.getItem('wmSession');
  const avatarEl = document.getElementById('profile-avatar-img');
  const usernameEl = document.getElementById('profile-username');
  const infoEl = document.getElementById('profile-info');
  if (!stored) {
    if (usernameEl) usernameEl.textContent = 'Guest';
    if (avatarEl) avatarEl.src = '';
    const settingsPreview = document.getElementById('profile-avatar-settings-img');
    if (settingsPreview) settingsPreview.src = '';
    if (infoEl) infoEl.textContent = '';
    return;
  }
  const current = JSON.parse(stored);
  if (usernameEl) usernameEl.textContent = current.user || current.fullName || 'User';
  // populate inputs
  populateProfileFields(current);
  // avatar stored in user.avatar (base64) or session key 'avatar'
  const avatar = (current.avatar || sessionStorage.getItem('profileAvatar')) || '';
  if (avatarEl) avatarEl.src = avatar || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400"><rect width="100%" height="100%" fill="%23eef2f8"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%23144e97" font-size="36">No Image</text></svg>';
  const settingsPreview = document.getElementById('profile-avatar-settings-img');
  if (settingsPreview) settingsPreview.src = avatar || '';
  if (infoEl) infoEl.textContent = current.info || '';
}

function openProfileFileDialog() {
  const input = document.getElementById('profile-file-input');
  if (input) input.click();
}

function profileFileSelected(e) {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = function(ev) { profileUploadImage(ev.target.result); };
  reader.readAsDataURL(f);
}

function openChangePasswordModal() {
  const overlay = document.getElementById('changePassOverlay');
  if (!overlay) return;
  // clear fields
  const stored = sessionStorage.getItem('wmSession');
  if (!stored) {
    document.getElementById('authOverlay').style.display = 'flex';
    toggleAuth('login');
    return;
  }
  document.getElementById('change-current-pass').value = '';
  document.getElementById('change-new-pass').value = '';
  document.getElementById('change-confirm-pass').value = '';
  overlay.style.display = 'flex';
}

function closeChangePasswordModal() {
  const overlay = document.getElementById('changePassOverlay');
  if (!overlay) return;
  overlay.style.display = 'none';
}

function handleChangePasswordSubmit() {
  const stored = sessionStorage.getItem('wmSession');
  if (!stored) return;
  const current = JSON.parse(stored);
  const cur = document.getElementById('change-current-pass').value;
  const nw = document.getElementById('change-new-pass').value;
  const conf = document.getElementById('change-confirm-pass').value;
  if (!cur || !nw || !conf) { alert('Fill all password fields'); return; }
  if (nw !== conf) { alert('New password and confirmation do not match'); return; }
  if (nw.length < 8) { alert('Use a stronger password with at least 8 characters.'); return; }
  const userMatch = USERS.find(u => u.user === current.user);
  if (!userMatch || userMatch.pass !== cur) { alert('Current password is incorrect.'); return; }
  userMatch.pass = nw;
  current.pass = nw;
  sessionStorage.setItem('wmSession', JSON.stringify(current));
  saveUsers();
  closeChangePasswordModal();
  alert('Password changed successfully.');
}

// make generatePasswordSuggestion work with modal new-pass id if present
