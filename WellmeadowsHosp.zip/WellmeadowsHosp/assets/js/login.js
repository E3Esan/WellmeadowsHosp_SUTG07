function doLogin() {
  const username = document.getElementById('li-user').value.trim();
  const password = document.getElementById('li-pass').value;
  const found = USERS.find(user => user.user === username && user.pass === password);

  if (!found) {
    document.getElementById('li-err').textContent = 'Invalid username or password';
    return;
  }

  sessionStorage.setItem('wmSession', JSON.stringify(found));
  document.getElementById('authOverlay').style.display = 'none';
  updateAuthButton();
}

function doRegister() {
  const username = document.getElementById('rg-user').value.trim();
  const password = document.getElementById('rg-pass').value;
  const role = document.getElementById('rg-role').value;
  const fullName = document.getElementById('rg-full-name') ? document.getElementById('rg-full-name').value.trim() : '';
  const email = document.getElementById('rg-email') ? document.getElementById('rg-email').value.trim() : '';
  const phone = document.getElementById('rg-phone') ? document.getElementById('rg-phone').value.trim() : '';

  if (!username || !password) {
    document.getElementById('rg-err').textContent = 'Username and password required';
    return;
  }

  if (USERS.find(user => user.user === username)) {
    document.getElementById('rg-err').textContent = 'Username already exists';
    return;
  }

  USERS.push({ user: username, pass: password, role, fullName: fullName || username, email, phone });
  saveUsers();
  document.getElementById('rg-err').textContent = '';
  toggleAuth('login');
  document.getElementById('li-user').value = username;
}

function logout() {
  sessionStorage.removeItem('wmSession');
  closeUserProfile();
  document.getElementById('authOverlay').style.display = 'flex';
  toggleAuth('login');
  updateAuthButton();
}

