function addRow(key, editIndex = null) {
  if (key === 'requisition') {
    const reqNoEl = document.getElementById('in-requisition-reqNo');
    const requestedByEl = document.getElementById('in-requisition-requestedBy');
    const wardEl = document.getElementById('in-requisition-ward');
    const dateEl = document.getElementById('in-requisition-date');
    const fileEl = document.getElementById('in-requisition-file');
    const itemRows = [...document.querySelectorAll('#requisition-item-list .req-item-row')];

    const items = itemRows.map(row => {
      const vals = {};
      ['itemNo', 'itemName', 'dosage', 'method', 'cost', 'qty'].forEach(field => {
        const input = row.querySelector(`input[name="${field}"]`);
        vals[field] = input ? input.value.trim() : '';
      });
      return vals;
    }).filter(item => item.itemNo || item.itemName || item.dosage || item.method || item.cost || item.qty);

    if (!items.length) {
      alert('Add at least one requisition item before saving.');
      return;
    }

    const finish = () => {
      const base = {
        reqNo: reqNoEl ? reqNoEl.value.trim() : '',
        requestedBy: requestedByEl ? requestedByEl.value.trim() : '',
        ward: wardEl ? wardEl.value.trim() : '',
        date: dateEl ? dateEl.value : '',
        file: '',
        fileName: '',
        status: 'Pending',
        taxRate: 20
      };

      items.forEach(item => {
        const qty = Number(item.qty || 0);
        const cost = Number(item.cost || 0);
        const subtotal = qty * cost;
        const tax = calculateTax(subtotal, base.taxRate);
        const total = subtotal + tax;

        const existing = editIndex !== null && DB.requisition[editIndex] ? DB.requisition[editIndex] : {};
        const row = stampRecord({
          ...existing,
          ...base,
          itemNo: item.itemNo,
          itemName: item.itemName,
          dosage: item.dosage,
          method: item.method,
          cost: cost,
          qty: qty,
          subtotal: subtotal,
          tax: tax,
          total: total,
        });

        if (!row.reqNo) row.reqNo = 'REQ' + Math.floor(1000 + Math.random() * 9000);
        if (editIndex !== null) {
          DB.requisition[editIndex] = row;
        } else {
          DB.requisition.push(row);
        }
      });

      save();
      render('requisition');
      requisitionItemCounter = 0;
      buildForm('requisition');
    };

    if (fileEl && fileEl.files && fileEl.files[0]) {
      const file = fileEl.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        const baseFile = { file: reader.result, fileName: file.name };
        items.forEach(item => Object.assign(item, baseFile));
        finish();
      };
      reader.readAsDataURL(file);
      return;
    }

    finish();
    return;
  }

  const schema = SCHEMA[key];
  const obj = {};
  const fileFields = schema.fields.filter(field => field === 'file' || field === 'refDoc');
  const fileEls = fileFields.map(field => ({ field, el: document.getElementById('in-' + key + '-' + field) }));

  const finish = () => {
    const current = editIndex !== null && DB[key] && DB[key][editIndex] ? DB[key][editIndex] : {};

    schema.fields.forEach(field => {
      if (field === 'file' || field === 'refDoc') return;
      const el = document.getElementById('in-' + key + '-' + field);
      if (!el) return;
      obj[field] = el.value;
      el.value = '';
    });

    const idField = schema.fields[0];
    if (!obj[idField]) {
      obj[idField] = current[idField] || key.toUpperCase().slice(0, 3) + Math.floor(1000 + Math.random() * 8999);
    }

    if (key === 'pharma' && obj.file) {
      obj.photo = obj.file;
    }

    if (key === 'appointment') {
      const fee = Number(obj.fee || current.fee || 0);
      const taxRate = Number(obj.taxRate || current.taxRate || 20);
      obj.tax = calculateTax(fee, taxRate);
      obj.total = fee + obj.tax;
      obj.paymentStatus = obj.paymentStatus || current.paymentStatus || 'Pending';
    }

    if (key === 'supply') {
      const cost = Number(obj.cost || current.cost || 0);
      const qty = Number(obj.qty || current.qty || 0);
      const subtotal = cost * qty;
      const taxRate = Number(obj.taxRate || current.taxRate || 20);
      obj.subtotal = subtotal;
      obj.tax = calculateTax(subtotal, taxRate);
      obj.total = subtotal + obj.tax;
      obj.paymentStatus = obj.paymentStatus || current.paymentStatus || 'Pending';
    }

    const finalRecord = { ...current, ...obj };
    if (editIndex !== null) {
      DB[key][editIndex] = stampRecord(finalRecord);
    } else {
      DB[key].push(stampRecord(finalRecord));
    }
    save();
    render(key);
  };

  const processFile = index => {
    if (index >= fileEls.length) {
      finish();
      return;
    }

    const { field, el } = fileEls[index];
    if (!el) {
      obj[field] = '';
      obj[field + 'Name'] = '';
      processFile(index + 1);
      return;
    }

    if (el.files && el.files[0]) {
      const file = el.files[0];
      const reader = new FileReader();

      reader.onload = () => {
        obj[field] = reader.result;
        obj[field + 'Name'] = file.name;
        if (key === 'pharma' && field === 'file') obj.photo = reader.result;
        el.value = '';
        processFile(index + 1);
      };

      reader.readAsDataURL(file);
    } else {
      obj[field] = '';
      obj[field + 'Name'] = '';
      el.value = '';
      processFile(index + 1);
    }
  };

  processFile(0);
}

function delRow(key, index) {
  DB[key].splice(index, 1);
  save();
  render(key);
}

function setSelectOptions(selectId, values, placeholder = 'Select an option') {
  const select = document.getElementById(selectId);
  if (!select) return;

  const opts = Array.from(new Set(values.filter(Boolean))).sort();
  select.innerHTML = `<option value="">${placeholder}</option>` + opts.map(value => `<option value="${value}">${value}</option>`).join('');
}

function buildSearchSuggestions() {
  const staffQuals = Array.from(new Set((DB.staff || []).map(s => s.qual).filter(Boolean))).sort();
  const patientAllergies = Array.from(new Set((DB.patient || []).map(p => p.allergies).filter(Boolean))).sort();
  const patientMedications = Array.from(new Set((DB.medication || []).map(m => m.drugName).filter(Boolean))).sort();
  const patientIllnesses = Array.from(new Set((DB.patient || [])
    .map(p => p.medicalRecord)
    .filter(Boolean)
    .map(text => text.split(/[.;]/)[0].trim())
    .filter(Boolean))).sort();

  setSelectOptions('staff-qualification-select', staffQuals, 'All qualifications');
  setSelectOptions('patient-allergy-select', patientAllergies, 'All allergies');
  setSelectOptions('patient-medication-select', patientMedications, 'All medications');
  setSelectOptions('patient-illness-select', patientIllnesses, 'All illness records');

  const staffList = document.getElementById('staff-search-suggestions');
  if (staffList) {
    staffList.innerHTML = staffQuals.map(value => `<option value="${value}"></option>`).join('');
  }

  const patientList = document.getElementById('patient-search-suggestions');
  if (patientList) {
    patientList.innerHTML = [...patientAllergies, ...patientMedications, ...patientIllnesses].map(value => `<option value="${value}"></option>`).join('');
  }
}

function getSearchFieldValue(row, field) {
  if (!row) return '';

  const medicationValues = (DB.medication || [])
    .filter(m => m.patNo === row.patNo)
    .map(m => m.drugName)
    .join(' ');

  const map = {
    all: () => Object.values(row).join(' '),
    name: () => [row.first, row.last, row.name, row.itemName, row.patientName].filter(Boolean).join(' '),
    staffNo: () => row.staffNo || '',
    position: () => row.position || '',
    qual: () => row.qual || '',
    qualification: () => row.qual || '',
    ward: () => `${row.ward || ''} ${row.wardNo || ''}`,
    patNo: () => row.patNo || '',
    status: () => row.status || '',
    localDoctor: () => row.localDoctor || '',
    allergies: () => row.allergies || '',
    medication: () => medicationValues || '',
    illness: () => row.medicalRecord || '',
    medicalRecord: () => row.medicalRecord || '',
    number: () => row.number || '',
    location: () => row.location || '',
    beds: () => row.beds || '',
    apptDate: () => row.apptDate || row.date || '',
    apptTime: () => row.apptTime || row.time || '',
    reqNo: () => row.reqNo || '',
    itemName: () => row.itemName || '',
    itemNo: () => row.itemNo || '',
    requestedBy: () => row.requestedBy || '',
    supNo: () => row.supNo || ''
  };

  const fn = map[field] || map.all;
  return String(fn()).toLowerCase();
}

