// ===== Data schema and database =====
const SCHEMA = {
  ward: {
    fields: ['number', 'name', 'location', 'beds', 'extn'],
    labels: ['Ward No', 'Ward Name', 'Location', 'Total Beds', 'Tel Extn']
  },
  staff: {
    fields: ['staffNo', 'first', 'last', 'address', 'tel', 'dob', 'sex', 'nin', 'position', 'salary', 'scale', 'ward', 'hours', 'contract', 'pay', 'qual', 'institution', 'workExperience', 'medicalRecord', 'photo', 'file'],
    labels: ['Staff No', 'First Name', 'Last Name', 'Address', 'Tel No', 'DOB', 'Sex', 'NIN', 'Position', 'Salary', 'Salary Scale', 'Ward Assigned', 'Hours/Week', 'Perm/Temp', 'Pay(W/M)', 'Qualification', 'Institution', 'Working Experience', 'Medical Record', 'Photo URL', 'Attachment']
  },
  patient: {
    fields: ['patNo', 'first', 'last', 'address', 'tel', 'dob', 'sex', 'marital', 'kinName', 'kinRel', 'localDoctor', 'allergies', 'medicalRecord', 'ward', 'bed', 'waitDate', 'placedDate', 'expLeave', 'actualLeave', 'status', 'refDoc', 'file'],
    labels: ['Patient No', 'First Name', 'Last Name', 'Address', 'Tel No', 'DOB', 'Sex', 'Marital Status', 'Next-of-Kin', 'Kin Relation', 'Local Doctor', 'Allergies', 'Medical Record', 'Ward Required', 'Bed No', 'Waitlist Date', 'Date Placed', 'Expected Leave', 'Actual Leave', 'Status', "Patient's Referral Document", 'Attachment']
  },
  outpatient: {
    fields: ['patNo', 'first', 'last', 'address', 'tel', 'dob', 'sex', 'localDoctor', 'apptDate', 'apptTime', 'refDoc', 'file'],
    labels: ['Patient No', 'First Name', 'Last Name', 'Address', 'Tel No', 'DOB', 'Sex', 'Local Doctor', 'Appt Date', 'Appt Time', "Patient's Referral Document", 'Attachment']
  },
  appointment: {
    fields: ['apptNo', 'patNo', 'consultant', 'staffNo', 'date', 'time', 'room', 'referral', 'reason', 'localDoctor', 'fee', 'taxRate', 'paymentStatus', 'total', 'uploadedAt', 'refDoc', 'file'],
    labels: ['Appointment No', 'Patient No', 'Consultant Name', 'Consultant Staff No', 'Date', 'Time', 'Exam Room', 'Referral Source', 'Reason/Notes', 'Local Doctor', 'Fee(£)', 'Tax %', 'Payment Status', 'Total(£)', 'Uploaded At', "Patient's Referral Document", 'Attachment']
  },
  medication: {
    fields: ['patNo', 'patName', 'ward', 'bed', 'drugNo', 'drugName', 'dosage', 'method', 'units', 'start', 'finish'],
    labels: ['Patient No', 'Patient Name', 'Ward', 'Bed No', 'Drug No', 'Drug Name', 'Dosage', 'Method', 'Units/Day', 'Start Date', 'Finish Date']
  },
  supply: {
    fields: ['itemNo', 'name', 'desc', 'qty', 'reorder', 'cost', 'taxRate', 'paymentStatus', 'total', 'uploadedAt', 'photo', 'file'],
    labels: ['Item No', 'Name', 'Description', 'Qty in Stock', 'Reorder Level', 'Cost/Unit(£)', 'Tax %', 'Payment Status', 'Total(£)', 'Uploaded At', 'Picture', 'Attachment']
  },
  pharma: {
    fields: ['drugNo', 'name', 'desc', 'dosage', 'method', 'qty', 'reorder', 'cost', 'file'],
    labels: ['Drug No', 'Name', 'Description', 'Dosage', 'Method', 'Qty in Stock', 'Reorder Level', 'Cost/Unit(£)', 'Product Image']
  },
  requisition: {
    fields: ['reqNo', 'requestedBy', 'ward', 'itemNo', 'itemName', 'dosage', 'method', 'cost', 'qty', 'subtotal', 'tax', 'total', 'status', 'date', 'uploadedAt', 'file'],
    labels: ['Requisition No', 'Requested By', 'Ward', 'Item/Drug No', 'Name', 'Dosage', 'Method', 'Cost/Unit', 'Qty', 'Subtotal', 'Tax', 'Total', 'Status', 'Date Ordered', 'Uploaded At', 'Attachment']
  },
  supplier: {
    fields: ['supNo', 'name', 'address', 'tel', 'fax', 'photo', 'file'],
    labels: ['Supplier No', 'Name', 'Address', 'Tel No', 'Fax No', 'Picture', 'Attachment']
  }
};

let DB = {
  ward: [
    { number: 11, name: 'Orthopaedic', location: 'Block E', beds: 20, extn: 7711 },
    { number: 12, name: 'Cardiology', location: 'Block E', beds: 18, extn: 7712 }
  ],
  staff: [
    { staffNo: 'S011', first: 'Moira', last: 'Samuel', address: '49 School Road, Broxburn', tel: '01506-45633', dob: '1961-05-30', sex: 'Female', nin: 'WB123423D', position: 'Charge Nurse', salary: 18760, scale: '1C', ward: 11, hours: 37.5, contract: 'P', pay: 'M', qual: 'BSc Nursing Studies', institution: 'Edinburgh University', workExperience: '12 years in acute elder care; led nurse training and ward coordination; previous experience in surgical recovery and rehabilitation.', medicalRecord: 'Experienced senior charge nurse with strong clinical leadership, medication administration oversight, and patient safety monitoring.', photo: 'photos/staff2.png' },
    { staffNo: 'S098', first: 'Carol', last: 'Cummings', address: '15 High Street Edinburgh', tel: '0131-334-5677', dob: '1975-02-14', sex: 'Female', nin: '', position: 'Staff Nurse', salary: 15000, scale: '1B', ward: 11, hours: 37.5, contract: 'P', pay: 'M', qual: '', institution: '', workExperience: '6 years in general ward nursing; experience with post-op care, patient assessment, and medication administration.', medicalRecord: 'General ward nurse with post-operative care experience and routine patient education responsibilities.', photo: 'photos/staff5.png' },
    { staffNo: 'S123', first: 'Morgan', last: 'Russell', address: '23A George Street Broxburn', tel: '01506-67676', dob: '1980-07-01', sex: 'Male', nin: '', position: 'Nurse', salary: 14000, scale: '1A', ward: 11, hours: 37.5, contract: 'T', pay: 'M', qual: '', institution: '', workExperience: '4 years in community nursing and emergency support; prior role in district health visiting.', medicalRecord: 'Community and emergency care nurse with assessment skills and care-plan documentation experience.', photo: 'photos/staff4.png' },
    { staffNo: 'S167', first: 'Robin', last: 'Plevin', address: '7 Glen Terrace Edinburgh', tel: '0131-339-6123', dob: '1978-03-22', sex: 'Male', nin: '', position: 'Staff Nurse', salary: 15200, scale: '1B', ward: 11, hours: 37.5, contract: 'P', pay: 'M', qual: '', institution: '', workExperience: '8 years in medical and geriatric wards; trained in observation rounds and rehabilitation support.', medicalRecord: 'Medical and geriatric ward nurse focused on observations, rehabilitation support, and patient monitoring.', photo: 'photos/staff1.png' },
    { staffNo: 'S234', first: 'Amy', last: "O'Donnell", address: '234 Princes Street Edinburgh', tel: '0131-334-9099', dob: '1985-11-09', sex: 'Female', nin: '', position: 'Nurse', salary: 14000, scale: '1A', ward: 11, hours: 37.5, contract: 'P', pay: 'M', qual: 'BSc Nursing Studies', institution: 'University of Edinburgh', workExperience: '3 years in cardiology and elderly inpatient support; experience with medication rounds, risk assessment, and patient education.', medicalRecord: 'Cardiology support nurse with medication-round experience, patient education responsibilities, and ongoing observational care.', photo: '' },
    { staffNo: 'S344', first: 'Laurence', last: 'Burns', address: '1 Apple Drive Edinburgh', tel: '0131-334-9100', dob: '1970-01-15', sex: 'Male', nin: '', position: 'Consultant', salary: 45000, scale: 'CON', ward: 11, hours: 40, contract: 'P', pay: 'M', qual: 'MD', institution: 'Edinburgh University', workExperience: '18 years in specialist medicine; previous consultant posts in general medicine, cardiology, and long-term care oversight.', medicalRecord: 'Consultant physician with specialist practice in medical oversight, patient review, and treatment planning.', photo: 'photos/staff3.png' }
  ],
  patient: [
    { patNo: 'P10451', first: 'Robert', last: 'Drumtree', address: '', tel: '', dob: '', sex: '', marital: '', kinName: '', kinRel: '', localDoctor: 'Dr. A. Morrison', allergies: 'Penicillin', medicalRecord: 'History of hip surgery and post-operative pain management. Allergic to penicillin. Regular monitoring for mobility and medication tolerance.', ward: 11, bed: 84, waitDate: '2004-01-12', placedDate: '2004-01-12', expLeave: '2004-01-17', actualLeave: '2004-01-16', status: 'Discharged' },
    { patNo: 'P10480', first: 'Steven', last: 'Parks', address: '', tel: '', dob: '', sex: '', marital: '', kinName: '', kinRel: '', localDoctor: 'Dr. S. Patel', allergies: 'None', medicalRecord: 'Post-operative recovery following orthopaedic treatment. No known drug allergies. Mobility improved and discharged on schedule.', ward: 11, bed: 79, waitDate: '2004-01-12', placedDate: '2004-01-14', expLeave: '2004-01-18', actualLeave: '2004-01-18', status: 'Discharged' },
    { patNo: 'P10563', first: 'David', last: 'Black', address: '', tel: '', dob: '', sex: '', marital: '', kinName: '', kinRel: '', localDoctor: 'Dr. L. Graham', allergies: 'Peanuts', medicalRecord: 'Diabetes review and wound care treatment. Peanut allergy noted. Requires careful dietary review and medication charting.', ward: 11, bed: 80, waitDate: '2004-01-13', placedDate: '2004-01-13', expLeave: '2004-01-27', actualLeave: '', status: 'In Ward' },
    { patNo: 'P10604', first: 'Ian', last: 'Thomson', address: '', tel: '', dob: '', sex: '', marital: '', kinName: '', kinRel: '', localDoctor: 'Dr. H. Singh', allergies: 'Latex', medicalRecord: 'Cardiac monitoring and mobility assessment. Latex allergy needs documentation on all care notes and equipment planning.', ward: 11, bed: 87, waitDate: '2004-01-14', placedDate: '2004-01-15', expLeave: '2004-01-25', actualLeave: '', status: 'In Ward' },
    { patNo: 'P10787', first: 'Peter', last: 'Smith', address: '', tel: '', dob: '', sex: '', marital: '', kinName: '', kinRel: '', localDoctor: 'Dr. M. Osborne', allergies: 'Sulphur drugs', medicalRecord: 'Short-stay assessment following infection treatment. Sulphur allergy documented; review antibiotics before prescribing.', ward: 11, bed: 84, waitDate: '2004-01-17', placedDate: '2004-01-17', expLeave: '2004-01-22', actualLeave: '', status: 'In Ward' },
    { patNo: 'P10234', first: 'Anne', last: 'Phelps', address: '44 North Bridges, Cannonmills, Edinburgh EH1 5GH', tel: '0131-332-4111', dob: '1933-12-12', sex: 'Female', marital: 'Single', kinName: 'James Phelps', kinRel: 'Son', localDoctor: 'Dr. C. Allen', allergies: 'None', medicalRecord: 'Awaiting placement for rehabilitation review. No major allergies. Needs slow mobility support and regular observation.', ward: '', bed: '', waitDate: '2004-02-21', placedDate: '', expLeave: '', actualLeave: '', status: 'Waiting List' }
  ],
  outpatient: [],
  appointment: [
    { apptNo: 'A1001', patNo: 'P10563', consultant: 'Dr Laurence Burns', staffNo: 'S344', date: '2004-02-18', time: '09:30', room: 'Room 3', referral: 'GP Referral', reason: 'Post-operative review and mobility assessment', localDoctor: 'Dr. L. Graham', file: '' },
    { apptNo: 'A1002', patNo: 'P10604', consultant: 'Dr Laurence Burns', staffNo: 'S344', date: '2004-02-20', time: '11:00', room: 'Clinic 2', referral: 'Ward transfer review', reason: 'Cardiac follow-up and treatment planning', localDoctor: 'Dr. H. Singh', file: '' }
  ],
  medication: [
    { patNo: 'P10034', patName: 'Robert MacDonald', ward: 11, bed: 84, drugNo: 10223, drugName: 'Morphine', dosage: '10mg/ml', method: 'Oral', units: 50, start: '2004-03-24', finish: '2004-04-24' },
    { patNo: 'P10034', patName: 'Robert MacDonald', ward: 11, bed: 84, drugNo: 10334, drugName: 'Tetracycline', dosage: '0.5mg/ml', method: 'IV', units: 10, start: '2004-03-24', finish: '2004-04-17' },
    { patNo: 'P10034', patName: 'Robert MacDonald', ward: 11, bed: 84, drugNo: 10223, drugName: 'Morphine', dosage: '10mg/ml', method: 'Oral', units: 10, start: '2004-04-25', finish: '2004-05-02' }
  ],
  supply: [
    { itemNo: 'IT001', name: 'Syringes', desc: 'Sterile disposable syringes', qty: 500, reorder: 100, cost: 0.15, photo: 'https://placehold.co/120x90/7ea5d8/ffffff?text=Syringes' },
    { itemNo: 'IT002', name: 'Sterile Dressings', desc: 'Wound dressing pads', qty: 300, reorder: 50, cost: 0.8, photo: 'https://placehold.co/120x90/d8c7b5/ffffff?text=Dressings' },
    { itemNo: 'IT003', name: 'Plastic Bags', desc: 'Non-surgical clinical waste bags', qty: 1000, reorder: 200, cost: 0.05, photo: 'https://placehold.co/120x90/9fc7b3/ffffff?text=Bags' },
    { itemNo: 'IT004', name: 'Aprons', desc: 'Disposable plastic aprons', qty: 600, reorder: 150, cost: 0.1, photo: 'https://placehold.co/120x90/dfb5b5/ffffff?text=Aprons' }
  ],
  pharma: [
    { drugNo: 10223, name: 'Morphine', desc: 'Strong opioid analgesic for severe pain', dosage: '10mg/ml', method: 'Oral', qty: 200, reorder: 50, cost: 27.75, category: 'Analgesic', uses: 'Severe pain control after surgery or trauma', sideEffects: 'Drowsiness, nausea, constipation, respiratory depression', warnings: 'Use only under clinical supervision; avoid alcohol and sedatives' },
    { drugNo: 10334, name: 'Tetracycline', desc: 'Broad-spectrum antibiotic', dosage: '0.5mg/ml', method: 'IV', qty: 150, reorder: 40, cost: 12.5, category: 'Antibiotic', uses: 'Treatment of bacterial infections', sideEffects: 'Nausea, photosensitivity, stomach upset', warnings: 'Avoid in pregnancy and with calcium-rich products' },
    { drugNo: 10401, name: 'Amoxicillin', desc: 'Penicillin-type antibiotic', dosage: '250mg', method: 'Oral', qty: 300, reorder: 80, cost: 8.2, category: 'Antibiotic', uses: 'Respiratory, ear, and urinary tract infections', sideEffects: 'Diarrhoea, rash, nausea', warnings: 'Check for penicillin allergy before administration' },
    { drugNo: 10402, name: 'Ciprofloxacin', desc: 'Fluoroquinolone antibiotic', dosage: '500mg', method: 'Oral', qty: 180, reorder: 60, cost: 14.4, category: 'Antibiotic', uses: 'Urinary, gastrointestinal, and bone infections', sideEffects: 'Dizziness, tendon irritation, stomach upset', warnings: 'Avoid in pregnancy and use cautiously with tendon disorders' },
    { drugNo: 10403, name: 'Ceftriaxone', desc: 'Third-generation cephalosporin', dosage: '1g', method: 'IV', qty: 120, reorder: 30, cost: 18.6, category: 'Antibiotic', uses: 'Severe bacterial infections and hospital treatment', sideEffects: 'Injection-site pain, diarrhoea, rash', warnings: 'Monitor for allergic reactions and biliary issues' },
    { drugNo: 10404, name: 'Lisinopril', desc: 'ACE inhibitor for blood pressure', dosage: '10mg', method: 'Oral', qty: 240, reorder: 75, cost: 6.8, category: 'Cardiovascular', uses: 'Hypertension and heart failure management', sideEffects: 'Cough, dizziness, low blood pressure', warnings: 'Monitor kidney function and potassium levels' },
    { drugNo: 10405, name: 'Metoprolol', desc: 'Beta-blocker for heart rhythm and blood pressure', dosage: '50mg', method: 'Oral', qty: 260, reorder: 90, cost: 7.3, category: 'Cardiovascular', uses: 'Hypertension, angina, and arrhythmia control', sideEffects: 'Fatigue, slow pulse, dizziness', warnings: 'Use with caution in asthma or bradycardia' },
    { drugNo: 10406, name: 'Atorvastatin', desc: 'Cholesterol-lowering statin', dosage: '20mg', method: 'Oral', qty: 220, reorder: 70, cost: 9.1, category: 'Lipid regulator', uses: 'Lower LDL cholesterol and reduce cardiovascular risk', sideEffects: 'Muscle aches, nausea, headache', warnings: 'Monitor liver function and avoid grapefruit juice' },
    { drugNo: 10407, name: 'Paracetamol', desc: 'Pain and fever reliever', dosage: '500mg', method: 'Oral', qty: 500, reorder: 120, cost: 2.15, category: 'Analgesic', uses: 'Mild to moderate pain and fever reduction', sideEffects: 'Rare liver issues with overdose', warnings: 'Do not exceed recommended dose' },
    { drugNo: 10408, name: 'Ibuprofen', desc: 'Non-steroidal anti-inflammatory drug', dosage: '400mg', method: 'Oral', qty: 350, reorder: 100, cost: 3.1, category: 'Anti-inflammatory', uses: 'Pain and inflammation relief', sideEffects: 'Stomach irritation, heartburn, dizziness', warnings: 'Avoid in kidney disease or gastric ulcers' },
    { drugNo: 10409, name: 'Salbutamol', desc: 'Bronchodilator for asthma relief', dosage: '2mg/ml', method: 'Inhaled', qty: 160, reorder: 40, cost: 11.2, category: 'Respiratory', uses: 'Relief of bronchospasm and wheezing', sideEffects: 'Tremor, palpitations, anxiety', warnings: 'Use inhaler technique correctly and monitor tachycardia' },
    { drugNo: 10410, name: 'Omeprazole', desc: 'Proton pump inhibitor', dosage: '20mg', method: 'Oral', qty: 210, reorder: 65, cost: 6.4, category: 'Gastrointestinal', uses: 'Acid reflux, gastric ulcers, dyspepsia', sideEffects: 'Headache, nausea, diarrhoea', warnings: 'Avoid long-term use without review' },
    { drugNo: 10411, name: 'Metformin', desc: 'Biguanide for type 2 diabetes', dosage: '500mg', method: 'Oral', qty: 240, reorder: 80, cost: 5.6, category: 'Diabetes', uses: 'Glycaemic control in type 2 diabetes', sideEffects: 'Nausea, stomach upset, diarrhoea', warnings: 'Monitor renal function and avoid alcohol misuse' }
  ],
  requisition: [
    { reqNo: '034567712', requestedBy: 'Moira Samuel', ward: 11, itemNo: 10223, itemName: 'Morphine', dosage: '10mg/ml', method: 'Oral', cost: 27.75, qty: 50, date: '2004-02-15' }
  ],
  supplier: [
    { supNo: 'SU01', name: 'MediSupply Ltd', address: '12 Industrial Est, Edinburgh', tel: '0131-500-1000', fax: '0131-500-1001', photo: 'https://placehold.co/120x90/4d7ea8/ffffff?text=MediSupply' },
    { supNo: 'SU02', name: 'PharmaCorp UK', address: '8 Fife Road, Glasgow', tel: '0141-600-2000', fax: '0141-600-2001', photo: 'https://placehold.co/120x90/8b6eb4/ffffff?text=PharmaCorp' }
  ],
  bedQueue: [
    { id: 'Q-1001', patientNo: 'P10234', patientName: 'Anne Phelps', ward: 11, priority: 'Urgent', status: 'Waiting', requestedAt: '2004-02-21' },
    { id: 'Q-1002', patientNo: 'P10480', patientName: 'Steven Parks', ward: 11, priority: 'Normal', status: 'Waiting', requestedAt: '2004-01-12' }
  ]
};

try {
  const saved = localStorage.getItem('wellmeadowsDB');
  if (saved) {
    DB = JSON.parse(saved);

    const amyIndex = (DB.staff || []).findIndex(item => String(item.staffNo) === 'S234');
    if (amyIndex >= 0) {
      const updatedAmy = {
        staffNo: 'S234',
        first: 'Amy',
        last: "O'Donnell",
        address: '234 Princes Street Edinburgh',
        tel: '0131-334-9099',
        dob: '1985-11-09',
        sex: 'Female',
        nin: '',
        position: 'Nurse',
        salary: 14000,
        scale: '1A',
        ward: 11,
        hours: 37.5,
        contract: 'P',
        pay: 'M',
        qual: 'BSc Nursing Studies',
        institution: 'University of Edinburgh',
        workExperience: '3 years in cardiology and elderly inpatient support; experience with medication rounds, risk assessment, and patient education.',
        medicalRecord: 'Cardiology support nurse with medication-round experience, patient education responsibilities, and ongoing observational care.',
        photo: ''
      };

      DB.staff[amyIndex] = { ...DB.staff[amyIndex], ...updatedAmy };
      try {
        localStorage.setItem('wellmeadowsDB', JSON.stringify(DB));
      } catch (e) {}
    }
  }
} catch (e) {}

function save() {
  try {
    localStorage.setItem('wellmeadowsDB', JSON.stringify(DB));
  } catch (e) {}
}

