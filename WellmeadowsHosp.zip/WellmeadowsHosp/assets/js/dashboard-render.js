// ===== Dashboard rendering =====
function renderDash() {
  const totalBeds = DB.ward.reduce((sum, ward) => sum + Number(ward.beds || 0), 0);
  const occupied = DB.patient.filter(patient => patient.status === 'In Ward').length;
  const waiting = DB.patient.filter(patient => patient.status === 'Waiting List').length;

  // Reorder cards by importance and combine beds into one block
  const patientCount = DB.patient.length;
  const waitingCount = DB.patient.filter(p => p.status === 'Waiting List').length;
  const bedsCardHtml = `<div style="display:flex;flex-direction:column;gap:6px"><div>Total: <b>${totalBeds}</b></div><div>Occupied: <b>${occupied}</b></div><div>Free: <b>${totalBeds - occupied}</b></div></div>`;

  const cards = [
    { label: 'Patients', value: patientCount, cls: 'patients big' },
    { label: 'Waiting Patients', value: waitingCount, cls: 'waiting medium' },
    { label: 'Beds', html: bedsCardHtml, cls: 'beds big' },
    { label: 'Staff Members', value: DB.staff.length, cls: 'members medium' },
    { label: 'Wards', value: DB.ward.length, cls: 'wards medium' },
    { label: 'Suppliers', value: DB.supplier.length, cls: 'supplier small' }
  ];

  // sort cards by size weight so they render left-to-right from big -> medium -> small
  function weightOf(cls) {
    if (!cls) return 2;
    if (cls.indexOf('big') >= 0 || cls.indexOf('large') >= 0) return 3;
    if (cls.indexOf('medium') >= 0) return 2;
    if (cls.indexOf('small') >= 0) return 1;
    return 2;
  }

  cards.sort((a, b) => weightOf(b.cls || '') - weightOf(a.cls || ''));

  document.getElementById('dashCards').innerHTML = cards.map(card => {
    const cls = card.cls || '';
    if (card.html) return `<div class="card ${cls}">${card.html}<span>${card.label}</span></div>`;
    return `<div class="card ${cls}"><b>${card.value}</b><span>${card.label}</span></div>`;
  }).join('');

  // render compact staff-on-duty list (Name | Time | Status)
  const staffHtml = [];
  staffHtml.push('<table class="staffList"><tr><th>Name</th><th style="width:110px">Time</th><th>Status</th><th style="width:70px">&nbsp;</th></tr>');
  DB.staff.forEach(staff => {
    const name = (staff.first + ' ' + (staff.last || '')).trim();
    const time = staff.hours ? (String(staff.hours) + 'h') : '-';
    const status = (staff.position ? staff.position + (staff.ward ? ' • Ward ' + staff.ward : '') : '');
    staffHtml.push(`<tr><td><b>${name}</b></td><td>${time}</td><td class="status">${status || '-'}</td><td><button class="infoBtn" onclick="openStaffDetail('${staff.staffNo}')">ℹ️</button></td></tr>`);
  });
  staffHtml.push('</table>');
  document.getElementById('staffWidget').innerHTML = staffHtml.join('');

  let wardHtml = '<tr><th>Ward No</th><th>Name</th><th>Location</th><th>Beds</th><th>Occupied</th><th>Free</th><th>Charge Nurse</th><th>Info</th></tr>';

  DB.ward.forEach(ward => {
    const occupiedBeds = DB.patient.filter(patient => String(patient.ward) === String(ward.number) && patient.status === 'In Ward').length;
    const chargeNurse = DB.staff.find(staff => String(staff.ward) === String(ward.number) && staff.position === 'Charge Nurse');

    wardHtml += `<tr><td>${ward.number}</td><td>${ward.name}</td><td>${ward.location}</td><td>${ward.beds}</td><td>${occupiedBeds}</td><td>${ward.beds - occupiedBeds}</td><td>${chargeNurse ? chargeNurse.first + ' ' + chargeNurse.last : '-'}</td><td><button class="infoBtn" onclick="openWardDetail('${ward.number}')">ℹ️ Info</button></td></tr>`;
  });

  document.getElementById('wardOverview').innerHTML = wardHtml;

  const patientQuick = DB.patient.slice(0, 5).map(patient => `
    <tr>
      <td>${patient.patNo || '-'}</td>
      <td>${patient.first || '-'} ${patient.last || ''}</td>
      <td>${patient.status || '-'}</td>
      <td><button class="infoBtn" onclick="openPatientDetail('${patient.patNo}')">ℹ️ Info</button></td>
    </tr>
  `).join('');

  const supplierQuick = DB.supplier.map(supplier => `
    <tr>
      <td>${supplier.supNo || '-'}</td>
      <td>${supplier.name || '-'}</td>
      <td><button class="infoBtn" onclick="openSupplierDetail('${supplier.supNo}')">ℹ️ Info</button></td>
    </tr>
  `).join('');

  const medicationQuick = DB.medication.slice(0, 5).map(med => `
    <tr>
      <td>${med.patNo || '-'}</td>
      <td>${med.drugName || '-'}</td>
      <td>${med.dosage || '-'}</td>
      <td><button class="infoBtn" onclick="openMedicationDetail('${med.patNo}')">ℹ️ Info</button></td>
    </tr>
  `).join('');

  const dashboardInfo = `
    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(260px,1fr)); gap:16px; margin-top:24px;">
      <div>
        <h2>Patient Snapshot</h2>
        <table>
          <tr><th>Patient No</th><th>Name</th><th>Status</th><th>Info</th></tr>
          ${patientQuick || '<tr><td colspan="4">No patients</td></tr>'}
        </table>
      </div>
      <div>
        <h2>Supplier Directory</h2>
        <table>
          <tr><th>Supplier No</th><th>Name</th><th>Info</th></tr>
          ${supplierQuick || '<tr><td colspan="3">No suppliers</td></tr>'}
        </table>
      </div>
      <div>
        <h2>Medication Snapshot</h2>
        <table>
          <tr><th>Patient</th><th>Drug</th><th>Dose</th><th>Info</th></tr>
          ${medicationQuick || '<tr><td colspan="4">No medications</td></tr>'}
        </table>
      </div>
    </div>
  `;

  const dashboardRoot = document.getElementById('dashboard');
  if (dashboardRoot) {
    const existing = dashboardRoot.querySelector('#dashboard-info-panel');
    if (existing) existing.remove();

    const panel = document.createElement('div');
    panel.id = 'dashboard-info-panel';
    panel.innerHTML = dashboardInfo;
    dashboardRoot.appendChild(panel);
  }

  renderDashboardSlideshow();
}

// ===== Dashboard slideshow and image modal =====
