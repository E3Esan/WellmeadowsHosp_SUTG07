const _origGenerate = typeof generatePasswordSuggestion === 'function' ? generatePasswordSuggestion : null;
function generatePasswordSuggestion() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  let out = '';
  for (let i = 0; i < 12; i++) out += chars[Math.floor(Math.random() * chars.length)];
  const modalNew = document.getElementById('change-new-pass');
  const panelNew = document.getElementById('profile-new-pass');
  if (modalNew) modalNew.value = out;
  if (panelNew) panelNew.value = out;
  return out;
}

// Add show/hide toggle buttons to all password inputs across the app
function enhancePasswordInputs() {
  const inputs = Array.from(document.querySelectorAll('input[type="password"]'));
  inputs.forEach(input => {
    // avoid duplicates
    if (input.dataset.pwEnhanced) return;
    input.dataset.pwEnhanced = '1';

    // ensure parent is positioned
    const parent = input.parentElement || input.parentNode;
    if (parent && getComputedStyle(parent).position === 'static') parent.style.position = 'relative';

    // wrap input in pw-wrap if not already
    if (!parent.classList.contains('pw-wrap')) {
      const wrapper = document.createElement('div');
      wrapper.className = 'pw-wrap';
      parent.replaceChild(wrapper, input);
      wrapper.appendChild(input);
    }

    // add persistent class so style doesn't change when type toggles
    input.classList.add('pw-input');

    // create toggle button
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pw-toggle';
    btn.title = 'Show password';
    btn.innerText = '👁';
    const show = (e) => { if (e) e.preventDefault(); input.type = 'text'; btn.classList.add('showing'); btn.title = 'Hide password'; };
    const hide = (e) => { if (e) e && e.preventDefault && e.preventDefault(); input.type = 'password'; btn.classList.remove('showing'); btn.title = 'Show password'; };

    // press-and-hold (mouse + touch)
    btn.addEventListener('mousedown', show);
    btn.addEventListener('touchstart', show, { passive: false });
    btn.addEventListener('mouseup', hide);
    btn.addEventListener('mouseleave', hide);
    btn.addEventListener('touchend', hide);
    btn.addEventListener('touchcancel', hide);

    // keyboard: show on keydown (Space/Enter), hide on keyup
    btn.addEventListener('keydown', function(e) {
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); show(); }
    });
    btn.addEventListener('keyup', function(e) {
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); hide(); }
    });

    // append button to wrapper
    const wrap = input.parentElement;
    wrap.appendChild(btn);
  });
}

// initialize when DOM is ready and also after any dynamic UI changes
window.addEventListener('DOMContentLoaded', enhancePasswordInputs);
// call immediately in case script loads after DOM
setTimeout(enhancePasswordInputs, 200);

function profileUploadImage(dataUrl) {
  try {
    const stored = sessionStorage.getItem('wmSession');
    if (stored) {
      const current = JSON.parse(stored);
      current.avatar = dataUrl;
      sessionStorage.setItem('wmSession', JSON.stringify(current));
      // also persist to USERS list
      const userMatch = USERS.find(u => u.user === current.user);
      if (userMatch) { userMatch.avatar = dataUrl; saveUsers(); }
    } else {
      sessionStorage.setItem('profileAvatar', dataUrl);
    }
    const avatarEl = document.getElementById('profile-avatar-img');
    if (avatarEl) avatarEl.src = dataUrl;
    const settingsPreview = document.getElementById('profile-avatar-settings-img');
    if (settingsPreview) settingsPreview.src = dataUrl;
    alert('Profile image updated.');
  } catch (err) { console.error(err); alert('Error saving image'); }
}

function removeProfileAvatar() {
  const stored = sessionStorage.getItem('wmSession');
  if (stored) {
    const current = JSON.parse(stored);
    delete current.avatar;
    sessionStorage.setItem('wmSession', JSON.stringify(current));
    const userMatch = USERS.find(u => u.user === current.user);
    if (userMatch) { delete userMatch.avatar; saveUsers(); }
  } else {
    sessionStorage.removeItem('profileAvatar');
  }
  const avatarEl = document.getElementById('profile-avatar-img');
  if (avatarEl) avatarEl.src = '';
  const settingsPreview = document.getElementById('profile-avatar-settings-img');
  if (settingsPreview) settingsPreview.src = '';
}

function profileDownloadImage() {
  const avatarEl = document.getElementById('profile-avatar-img');
  if (!avatarEl || !avatarEl.src) { alert('No image to download'); return; }
  const a = document.createElement('a');
  a.href = avatarEl.src;
  a.download = (document.getElementById('profile-username') ? document.getElementById('profile-username').textContent : 'profile') + '.png';
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function saveProfileInfo() {
  const stored = sessionStorage.getItem('wmSession');
  const infoEl = document.getElementById('profile-info');
  const info = infoEl ? infoEl.textContent.trim() : '';
  if (stored) {
    const current = JSON.parse(stored);
    current.info = info;
    sessionStorage.setItem('wmSession', JSON.stringify(current));
    const userMatch = USERS.find(u => u.user === current.user);
    if (userMatch) { userMatch.info = info; saveUsers(); }
  } else {
    sessionStorage.setItem('profileInfo', info);
  }
  alert('Profile info saved.');
}

function openProfileImageOptions() {
  // open file dialog when avatar clicked
  openProfileFileDialog();
}



function changePassword() {
  const stored = sessionStorage.getItem('wmSession');
  if (!stored) return;

  const current = JSON.parse(stored);
  const currentPass = document.getElementById('profile-current-pass').value;
  const newPass = document.getElementById('profile-new-pass').value;

  if (!currentPass || !newPass) {
    alert('Enter the current password and the new password.');
    return;
  }

  const userMatch = USERS.find(user => user.user === current.user);
  if (!userMatch || userMatch.pass !== currentPass) {
    alert('Current password is incorrect.');
    return;
  }

  if (newPass.length < 8) {
    alert('Use a stronger password with at least 8 characters.');
    return;
  }

  userMatch.pass = newPass;
  current.pass = newPass;
  sessionStorage.setItem('wmSession', JSON.stringify(current));
  saveUsers();
  document.getElementById('profile-current-pass').value = '';
  document.getElementById('profile-new-pass').value = '';
  alert('Password updated successfully.');
}

