function syncBedQueue() {
  if (!Array.isArray(DB.bedQueue)) DB.bedQueue = [];

  const waiting = DB.patient.filter(patient => {
    const status = String(patient.status || '').toLowerCase();
    return status === 'waiting list' || status === 'queued' || status === 'waiting';
  });

  const seen = new Set();
  DB.bedQueue = DB.bedQueue.filter(entry => {
    if (entry.status === 'Admitted') return false;
    const patient = DB.patient.find(item => item.patNo === entry.patientNo);
    const stillWaiting = patient && ['waiting list', 'queued', 'waiting'].includes(String(patient.status || '').toLowerCase());
    const key = `${entry.patientNo}|${entry.ward || ''}`;
    if (!stillWaiting || seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  waiting.forEach(patient => {
    const patientName = `${patient.first || ''} ${patient.last || ''}`.trim();
    const ward = patient.ward || '';
    const match = DB.bedQueue.find(entry => entry.patientNo === patient.patNo && String(entry.ward) === String(ward));
    if (!match) {
      DB.bedQueue.push({
        id: 'Q-' + String(Date.now() + Math.random()).slice(-6),
        patientNo: patient.patNo,
        patientName,
        ward,
        priority: patient.priority || 'Normal',
        status: 'Waiting',
        requestedAt: patient.waitDate || new Date().toISOString().slice(0, 10)
      });
    }
  });

  save();
  return DB.bedQueue;
}

function allocateBedNumber(targetWard, currentPatientNo = null) {
  const wardInfo = DB.ward.find(ward => String(ward.number) === String(targetWard));
  if (!wardInfo) return null;

  const occupied = DB.patient
    .filter(item => String(item.ward) === String(targetWard) && String(item.status).toLowerCase() === 'in ward' && String(item.patNo) !== String(currentPatientNo))
    .map(item => Number(item.bed || 0));

  for (let bed = 1; bed <= Number(wardInfo.beds || 0); bed++) {
    if (!occupied.includes(bed)) return bed;
  }
  return null;
}

function admitQueuePatient(queueId, wardNo) {
  const queue = syncBedQueue();
  const entry = queue.find(item => item.id === queueId) || queue.find(item => String(item.ward) === String(wardNo || ''));
  if (!entry) return;

  const patient = DB.patient.find(item => item.patNo === entry.patientNo);
  if (!patient) return;

  const targetWard = String(wardNo || entry.ward || patient.ward || '');
  const nextBed = allocateBedNumber(targetWard, patient.patNo);

  patient.status = 'In Ward';
  patient.ward = targetWard;
  patient.placedDate = patient.placedDate || new Date().toISOString().slice(0, 10);
  patient.bed = nextBed ? String(nextBed) : (patient.bed || 'Pending');
  patient.priority = entry.priority || patient.priority || 'Normal';

  if (entry) {
    entry.status = 'Admitted';
    entry.admittedAt = new Date().toISOString();
  }

  DB.bedQueue = DB.bedQueue.filter(item => item.id !== (entry && entry.id));
  save();
  renderBeds();
  render('patient');
}

function updateQueuePriority(queueId, priority) {
  const entry = (DB.bedQueue || []).find(item => item.id === queueId);
  if (!entry) return;
  entry.priority = priority;
  save();
  renderBeds();
}

function addBedQueueEntry(entry) {
  const queue = Array.isArray(DB.bedQueue) ? DB.bedQueue : [];
  const clean = {
    id: entry.id || 'Q-' + Date.now(),
    patientNo: entry.patientNo || '',
    patientName: entry.patientName || '',
    ward: entry.ward || '',
    priority: entry.priority || 'Normal',
    status: entry.status || 'Waiting',
    requestedAt: entry.requestedAt || new Date().toISOString().slice(0, 10)
  };

  if (!clean.patientNo && !clean.patientName) {
    alert('Enter patient details before saving to the queue.');
    return;
  }

  const index = queue.findIndex(item => item.id === clean.id);
  if (index >= 0) {
    queue[index] = { ...queue[index], ...clean };
  } else {
    queue.push(clean);
  }

  DB.bedQueue = queue;
  save();
  renderBeds();
}

function editBedQueueEntry(queueId) {
  const entry = (DB.bedQueue || []).find(item => item.id === queueId);
  if (!entry) return;

  document.getElementById('queue-patient-no').value = entry.patientNo || '';
  document.getElementById('queue-patient-name').value = entry.patientName || '';
  document.getElementById('queue-ward').value = entry.ward || '';
  document.getElementById('queue-priority').value = entry.priority || 'Normal';
  document.getElementById('queue-status').value = entry.status || 'Waiting';
  document.getElementById('queue-requested-at').value = entry.requestedAt || '';
  document.getElementById('queue-edit-id').value = entry.id;
  document.getElementById('queue-form-title').textContent = 'Edit Queue Entry';
}

function removeBedQueueEntry(queueId) {
  DB.bedQueue = (DB.bedQueue || []).filter(item => item.id !== queueId);
  save();
  renderBeds();
}

function submitBedQueueForm() {
  const patientNo = document.getElementById('queue-patient-no').value.trim();
  const patientName = document.getElementById('queue-patient-name').value.trim();
  const ward = document.getElementById('queue-ward').value.trim();
  const priority = document.getElementById('queue-priority').value;
  const status = document.getElementById('queue-status').value;
  const requestedAt = document.getElementById('queue-requested-at').value;
  const editId = document.getElementById('queue-edit-id').value;

  if (!patientNo && !patientName) {
    alert('Patient number or name is required.');
    return;
  }

  addBedQueueEntry({
    id: editId || undefined,
    patientNo,
    patientName,
    ward,
    priority,
    status,
    requestedAt
  });

  document.getElementById('queue-patient-no').value = '';
  document.getElementById('queue-patient-name').value = '';
  document.getElementById('queue-ward').value = '';
  document.getElementById('queue-priority').value = 'Normal';
  document.getElementById('queue-status').value = 'Waiting';
  document.getElementById('queue-requested-at').value = new Date().toISOString().slice(0, 10);
  document.getElementById('queue-edit-id').value = '';
  document.getElementById('queue-form-title').textContent = 'Add Queue Entry';
}

function renderBeds() {
  syncBedQueue();

  const queuePanel = document.getElementById('bedQueuePanel');
  const bedsHtml = DB.ward.map(ward => {
    const occupied = DB.patient.filter(patient => String(patient.ward) === String(ward.number) && patient.status === 'In Ward').length;
    const free = ward.beds - occupied;
    const percent = Math.min(100, Math.round((occupied / ward.beds) * 100));
    const queueItems = (DB.bedQueue || []).filter(item => String(item.ward) === String(ward.number));

    return `<div class="wardbox" style="padding:12px;border:1px solid var(--bd);border-radius:12px;background:#fff;">
      <h3>Ward ${ward.number} – ${ward.name}</h3>
      <span class="tag">${ward.location}</span>
      <div class="bar"><div style="width:${percent}%"></div></div>
      <div>${occupied}/${ward.beds} occupied</div>
      <div class="${free > 0 ? 'free' : 'full'}">${free > 0 ? free + ' beds free' : 'FULL'}</div>
      <div style="margin-top:12px;font-size:12px;color:#456;">
        <strong>Queue (${queueItems.length})</strong>
        ${queueItems.length ? queueItems.slice(0, 3).map(item => `<div style="margin-top:6px;display:flex;justify-content:space-between;gap:6px;align-items:center;"><span>${item.patientName}</span><span style="font-size:11px;padding:2px 6px;border-radius:999px;background:#eef5ff;color:#234;">${item.priority}</span></div>`).join('') : '<div style="margin-top:6px; color:#678;">No patients waiting</div>'}
      </div>
      <div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap;">
        <button class="act" onclick="admitQueuePatient('${queueItems[0] ? queueItems[0].id : ''}', ${ward.number})" ${queueItems.length ? '' : 'disabled'}>Admit next</button>
      </div>
    </div>`;
  }).join('');

  document.getElementById('bedGrid').innerHTML = bedsHtml;

  const queueRows = (DB.bedQueue || []).map(item => `
    <tr>
      <td>${item.patientName}</td>
      <td>${item.patientNo}</td>
      <td>${item.ward || '-'}</td>
      <td>
        <select onchange="updateQueuePriority('${item.id}', this.value)">
          <option value="Urgent" ${item.priority === 'Urgent' ? 'selected' : ''}>Urgent</option>
          <option value="Normal" ${item.priority === 'Normal' ? 'selected' : ''}>Normal</option>
          <option value="Routine" ${item.priority === 'Routine' ? 'selected' : ''}>Routine</option>
        </select>
      </td>
      <td>${item.status || 'Waiting'}</td>
      <td>${item.requestedAt || '-'}</td>
      <td>
        <button class="infoBtn" onclick="editBedQueueEntry('${item.id}')">Edit</button>
        <button class="act" onclick="admitQueuePatient('${item.id}', ${item.ward || 0})">Admit</button>
        <button class="del" onclick="removeBedQueueEntry('${item.id}')">Del</button>
      </td>
    </tr>
  `).join('');

  queuePanel.innerHTML = `
    <div style="border:1px solid var(--bd); border-radius:12px; padding:14px; background:#fff;">
      <h3 style="margin:0 0 10px;">Bed Queue Management</h3>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px; margin-bottom:12px; border:1px solid var(--bd); border-radius:8px; padding:10px; background:#f8fbff;">
        <div><label style="display:block;font-size:11px;color:#456;">Patient No</label><input id="queue-patient-no" style="width:100%;"></div>
        <div><label style="display:block;font-size:11px;color:#456;">Patient Name</label><input id="queue-patient-name" style="width:100%;"></div>
        <div><label style="display:block;font-size:11px;color:#456;">Ward</label><input id="queue-ward" style="width:100%;"></div>
        <div><label style="display:block;font-size:11px;color:#456;">Priority</label><select id="queue-priority" style="width:100%;"><option value="Urgent">Urgent</option><option value="Normal" selected>Normal</option><option value="Routine">Routine</option></select></div>
        <div><label style="display:block;font-size:11px;color:#456;">Status</label><select id="queue-status" style="width:100%;"><option value="Waiting" selected>Waiting</option><option value="Review">Review</option><option value="Admitted">Admitted</option></select></div>
        <div><label style="display:block;font-size:11px;color:#456;">Requested</label><input id="queue-requested-at" type="date" style="width:100%;" value="${new Date().toISOString().slice(0, 10)}"></div>
        <input id="queue-edit-id" type="hidden" value="">
      </div>
      <div style="display:flex;gap:8px;align-items:center; margin-bottom:12px;">
        <strong id="queue-form-title">Add Queue Entry</strong>
        <button class="act" onclick="submitBedQueueForm()">Save Queue Entry</button>
      </div>
      <table style="width:100%; border-collapse:collapse;">
        <thead>
          <tr><th>Patient</th><th>Patient No</th><th>Ward</th><th>Priority</th><th>Status</th><th>Requested</th><th>Action</th></tr>
        </thead>
        <tbody>${queueRows || '<tr><td colspan="7" style="padding:10px; color:#678;">No patients in the bed queue.</td></tr>'}</tbody>
      </table>
    </div>
  `;
}

setTheme((localStorage.getItem('wmTheme') || 'light') === 'dark');
show('dashboard');

/* username and password for login */
