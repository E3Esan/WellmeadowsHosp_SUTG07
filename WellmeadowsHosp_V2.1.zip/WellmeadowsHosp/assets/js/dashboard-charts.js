// ===== Dashboard charts (Chart.js) =====
// renderDash() (dashboard-render.js) calls renderDashboardCharts() at the end
// of every dashboard render, so these always reflect the live DB data.
//
// Each chart can be switched between Pie / Bar / Line at any time — the
// buttons are built automatically next to each chart's title. The choice is
// remembered per chart (per browser) via localStorage.
const CHART_REGISTRY = {};   // canvasId -> live Chart.js instance
const CHART_CONFIGS = {};    // canvasId -> { labels, datasets, type, pieDatasetIndex, indexAxis }

const CHART_PALETTE = ['#005EB8', '#61b878', '#f0a63a', '#c0392b', '#8b6eb4', '#2b7bd3', '#c9a227', '#6c757d', '#3fa7d6', '#e07a5f'];
const CHART_TYPES = [
  { value: 'pie', label: '🥧 Pie' },
  { value: 'bar', label: '📊 Bar' },
  { value: 'line', label: '📈 Line' }
];

function chartTextColor() {
  return document.body.classList.contains('dark-mode') ? '#dce6f2' : '#22303f';
}

// Builds/refreshes the Pie/Bar/Line button row for one chart.
function buildChartTypeSwitcher(canvasId) {
  const host = document.getElementById('switch-' + canvasId);
  if (!host) return;
  const cfg = CHART_CONFIGS[canvasId];

  host.innerHTML = CHART_TYPES.map(t =>
    `<button type="button" class="chartTypeBtn${t.value === cfg.type ? ' active' : ''}" onclick="setChartType('${canvasId}','${t.value}')">${t.label}</button>`
  ).join('');
}

// Called by the Pie/Bar/Line buttons.
function setChartType(canvasId, type) {
  const cfg = CHART_CONFIGS[canvasId];
  if (!cfg) return;
  cfg.type = type;
  localStorage.setItem('chartType:' + canvasId, type);
  drawChart(canvasId);
  buildChartTypeSwitcher(canvasId);
}

// Registers a chart's data + allowed shape, then draws it. Call this (not
// drawChart directly) whenever the dashboard re-renders, since the
// underlying labels/datasets may have changed.
//   registerChart(canvasId, labels, datasets, {
//     defaultType: 'bar' | 'pie' | 'line',
//     pieDatasetIndex: which dataset becomes the pie slice values when more
//                      than one dataset exists (default 0),
//     indexAxis: 'y' for horizontal bars
//   })
function registerChart(canvasId, labels, datasets, opts = {}) {
  const savedType = localStorage.getItem('chartType:' + canvasId);
  CHART_CONFIGS[canvasId] = {
    labels,
    datasets,
    type: savedType || opts.defaultType || 'bar',
    pieDatasetIndex: opts.pieDatasetIndex || 0,
    indexAxis: opts.indexAxis || 'x'
  };
  buildChartTypeSwitcher(canvasId);
  drawChart(canvasId);
}

function drawChart(canvasId) {
  const cfg = CHART_CONFIGS[canvasId];
  const canvas = document.getElementById(canvasId);
  if (!cfg || !canvas || typeof Chart === 'undefined') return;

  if (CHART_REGISTRY[canvasId]) CHART_REGISTRY[canvasId].destroy();

  const textColor = chartTextColor();
  Chart.defaults.color = textColor;
  Chart.defaults.font.family = "'Segoe UI', Arial, sans-serif";

  let datasets;
  let options = { plugins: { legend: { position: 'bottom' } } };

  if (cfg.type === 'pie') {
    // Pie only shows one series — pick the configured dataset (or sum all
    // datasets if there's just conceptually one metric split by label).
    const primary = cfg.datasets[cfg.pieDatasetIndex] || cfg.datasets[0];
    datasets = [{
      data: primary.data,
      backgroundColor: cfg.labels.map((_, i) => CHART_PALETTE[i % CHART_PALETTE.length])
    }];
  } else if (cfg.type === 'line') {
    datasets = cfg.datasets.map((ds, i) => ({
      ...ds,
      borderColor: CHART_PALETTE[i % CHART_PALETTE.length],
      backgroundColor: CHART_PALETTE[i % CHART_PALETTE.length],
      fill: false,
      tension: 0.35,
      pointRadius: 3
    }));
    options.scales = { y: { beginAtZero: true, ticks: { precision: 0 } } };
  } else { // bar
    datasets = cfg.datasets.map((ds, i) => ({
      ...ds,
      backgroundColor: ds.backgroundColor || CHART_PALETTE[i % CHART_PALETTE.length]
    }));
    options.indexAxis = cfg.indexAxis;
    options.scales = { [cfg.indexAxis === 'y' ? 'x' : 'y']: { beginAtZero: true, ticks: { precision: 0 } } };
    if (cfg.datasets.length < 2) options.plugins.legend.display = false;
  }

  CHART_REGISTRY[canvasId] = new Chart(canvas.getContext('2d'), {
    type: cfg.type === 'pie' ? 'pie' : cfg.type,
    data: { labels: cfg.labels, datasets },
    options
  });
}

function renderDashboardCharts() {
  if (typeof Chart === 'undefined') return; // Chart.js CDN not reachable — dashboard still works without it

  // ---- Bed occupancy ----
  const totalBeds = DB.ward.reduce((sum, w) => sum + Number(w.beds || 0), 0);
  const occupied = DB.patient.filter(p => p.status === 'In Ward').length;
  registerChart('chartBedOccupancy',
    ['Occupied', 'Free'],
    [{ label: 'Beds', data: [occupied, Math.max(0, totalBeds - occupied)] }],
    { defaultType: 'pie' }
  );

  // ---- Patients by status ----
  const statusCounts = {};
  DB.patient.forEach(p => { const s = p.status || 'Unknown'; statusCounts[s] = (statusCounts[s] || 0) + 1; });
  registerChart('chartPatientStatus',
    Object.keys(statusCounts),
    [{ label: 'Patients', data: Object.values(statusCounts) }],
    { defaultType: 'bar' }
  );

  // ---- Staff by position ----
  const posCounts = {};
  DB.staff.forEach(s => { const p = s.position || 'Other'; posCounts[p] = (posCounts[p] || 0) + 1; });
  registerChart('chartStaffPosition',
    Object.keys(posCounts),
    [{ label: 'Staff', data: Object.values(posCounts) }],
    { defaultType: 'pie' }
  );

  // ---- Ward occupancy (beds vs occupied) ----
  const wardLabels = DB.ward.map(w => `Ward ${w.number}`);
  const wardBeds = DB.ward.map(w => Number(w.beds || 0));
  const wardOcc = DB.ward.map(w => DB.patient.filter(p => String(p.ward) === String(w.number) && p.status === 'In Ward').length);
  registerChart('chartWardOccupancy',
    wardLabels,
    [
      { label: 'Total Beds', data: wardBeds },
      { label: 'Occupied', data: wardOcc }
    ],
    { defaultType: 'bar', indexAxis: 'y', pieDatasetIndex: 1 }
  );

  // ---- Stock vs reorder level (supplies + pharma combined, top 10) ----
  const stockItems = [
    ...DB.supply.map(s => ({ name: s.name, qty: Number(s.qty || 0), reorder: Number(s.reorder || 0) })),
    ...DB.pharma.map(p => ({ name: p.name, qty: Number(p.qty || 0), reorder: Number(p.reorder || 0) }))
  ].slice(0, 10);
  registerChart('chartStockLevels',
    stockItems.map(i => i.name),
    [
      { label: 'In Stock', data: stockItems.map(i => i.qty) },
      { label: 'Reorder Level', data: stockItems.map(i => i.reorder) }
    ],
    { defaultType: 'bar', pieDatasetIndex: 0 }
  );

  // ---- Requisitions by status ----
  const reqCounts = {};
  DB.requisition.forEach(r => { const s = r.status || 'Pending'; reqCounts[s] = (reqCounts[s] || 0) + 1; });
  registerChart('chartRequisitionStatus',
    Object.keys(reqCounts),
    [{ label: 'Requisitions', data: Object.values(reqCounts) }],
    { defaultType: 'pie' }
  );
}
